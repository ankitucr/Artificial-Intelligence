const natural = require('natural');
const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

let tokenizer = new natural.WordTokenizer();
let language = "EN";
let lexicon = new natural.Lexicon(language);
let ruleSet = new natural.RuleSet(language);
let tagger = new natural.BrillPOSTagger(lexicon, ruleSet);

let context = {};

app.post('/process', (req, res) => {
    let text = req.body.text;
    let tokens = tokenizer.tokenize(text);
    let taggedTokens = tagger.tag(tokens);

    let intent = getIntent(taggedTokens);
    let entities = getEntities(taggedTokens);

    let response = generateResponse(intent, entities, context);

    res.json({ response: response });
});

function getIntent(taggedTokens) {
    let intent = null;
    for (let i = 0; i < taggedTokens.length; i++) {
        if (taggedTokens[i][1] === 'NN') {
            intent = taggedTokens[i][0];
            break;
        }
    }
    return intent;
}

function getEntities(taggedTokens) {
    let entities = [];
    for (let i = 0; i < taggedTokens.length; i++) {
        if (taggedTokens[i][1] === 'NNP') {
            entities.push(taggedTokens[i][0]);
        }
    }
    return entities;
}

function generateResponse(intent, entities, context) {
    let response = '';
    if (intent === 'greeting') {
        response = 'Hello, how can I assist you today?';
    } else if (intent === 'goodbye') {
        response = 'Goodbye, it was nice talking to you.';
    } else {
        response = 'I did not understand your request.';
    }

    if (entities.length > 0) {
        response += ' You mentioned ' + entities.join(', ');
    }

    return response;
}

app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
});