const express = require('express');
const app = express();
const port = 3000;
const axios = require('axios');
const natural = require('natural');
const stopwords = require('stopwords').english;
const WordTokenizer = new natural.WordTokenizer();
const TfIdf = new natural.TfIdf();

app.use(express.json());

let documents = [];

app.post('/add-document', (req, res) => {
    const document = req.body.document;
    documents.push(document);
    TfIdf.addDocument(document);
    res.send(`Document added: ${document}`);
});

app.post('/search', (req, res) => {
    const query = req.body.query;
    const tokenizedQuery = WordTokenizer.tokenize(query);
    const filteredQuery = tokenizedQuery.filter(word => !stopwords.includes(word.toLowerCase()));
    const results = TfIdf.listTerms(0);
    const scoredResults = results.filter(result => filteredQuery.includes(result.term));
    scoredResults.sort((a, b) => b.tfidf - a.tfidf);
    res.send(scoredResults);
});

app.post('/generate', (req, res) => {
    const prompt = req.body.prompt;
    const tokenizedPrompt = WordTokenizer.tokenize(prompt);
    const filteredPrompt = tokenizedPrompt.filter(word => !stopwords.includes(word.toLowerCase()));
    const generatedText = '';
    const words = documents.join(' ').split(' ');
    const wordMap = {};
    words.forEach(word => {
        if (!wordMap[word]) {
            wordMap[word] = [];
        }
        wordMap[word].push(words[words.indexOf(word) + 1]);
    });
    let currentWord = filteredPrompt[0];
    for (let i = 0; i < 100; i++) {
        if (wordMap[currentWord]) {
            currentWord = wordMap[currentWord][Math.floor(Math.random() * wordMap[currentWord].length)];
            generatedText += ' ' + currentWord;
        } else {
            break;
        }
    }
    res.send(generatedText);
});

app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
});