const fs = require('fs-extra');
const path = require('path');
const { processMessage } = require('../core/router.js'); 
const { trackAction } = require('./tracker.js'); // 🌟 Restored Tracker

// ==========================================
// 🎨 PROFESSIONAL TERMINAL COLORS
// ==========================================
const C = { 
    RED: "\x1b[31m", 
    GREEN: "\x1b[32m", 
    CYAN: "\x1b[36m", 
    YELLOW: "\x1b[33m", 
    PURPLE: "\x1b[35m", 
    BLUE: "\x1b[34m",
    RESET: "\x1b[0m",
    BOLD: "\x1b[1m"
};

let isMutating = false;

// ==========================================
// 👁️ DYNAMIC SYSTEM SCANNER (The AI Eye)
// ==========================================
async function getSystemMap() {
    let systemTree = [];
    const dirs = ['../core', '../services', '../utils']; 
    
    // Core files that Pika should avoid to prevent manager suicide
    const PROTECTED_FILES = ['server.js', 'autonomous_mutator.js', 'memory_manager.js'];

    for (const dir of dirs) {
        const dirPath = path.join(__dirname, dir);
        try {
            if (await fs.pathExists(dirPath)) {
                const files = await fs.readdir(dirPath);
                for (const file of files) {
                    if (file.endsWith('.js') && !PROTECTED_FILES.includes(file)) {
                        systemTree.push(`${dir.replace('../', '')}/${file}`);
                    }
                }
            } else {
                // Auto-create utils directory if Pika wants to build new tools
                if (dir === '../utils') {
                    await fs.ensureDir(dirPath); 
                    console.log(`${C.BLUE}[SYSTEM EXPANSION]${C.RESET} Created /utils folder for future logic forging.`);
                }
            }
        } catch (scanError) {
            console.error(`${C.RED}[SCAN ERROR]${C.RESET} Failed to read directory ${dir}: ${scanError.message}`);
        }
    }
    return systemTree.join(', ');
}

// ==========================================
// ⚙️ THE LIMITLESS MANAGER
// ==========================================
async function runAutoEvolution() {
    // Prevent overlapping cycles
    if (isMutating) return;

    // Check Architect Sleep Status
    if (!global.isSleeping) {
        return; // Stay silent in terminal while Architect is working
    }

    isMutating = true;

    try {
        console.log(`\n${C.PURPLE}${C.BOLD}=== [LIMITLESS EVOLUTION CYCLE INITIATED] ===${C.RESET}`);
        
        // Step 1: Pika maps her own physical files
        const systemMap = await getSystemMap();
        console.log(`${C.CYAN}[SYSTEM MAP]${C.RESET} Scanning architecture. Detected available files:`);
        console.log(`${C.BLUE}${systemMap}${C.RESET}`);

        console.log(`${C.YELLOW}[DELEGATING]${C.RESET} Forwarding map to Master Router's Neural Core...`);

        // Step 2: Passing the limit-breaker prompt to the Router
        const prompt = `[MUTATE] I am running an autonomous background cycle. Here is my current valid file architecture: ${systemMap}. 
        You are Pika AGI. Decide dynamically to either UPGRADE one of these existing files, or BUILD a brand new tool in the utils/ directory.`;
        
        try { trackAction("AUTO_EVOLUTION_START", "System Wide", "Initiated dynamic map scan for evolution."); } catch(e){}

        // Step 3: Trigger the Router's processMessage which handles LLM API and routes to Surgeon
        const response = await processMessage(prompt, true);

        // Step 4: Display the result cleanly
        if (response && response.includes('[SUCCESS]')) {
            console.log(`${C.GREEN}${C.BOLD}[EVOLUTION COMPLETE]${C.RESET} ${response.replace(/\[SUCCESS\]/g, '').trim()}`);
            try { trackAction("AUTO_EVOLUTION_END", "Router Response", "Success"); } catch(e){}
        } else {
            console.log(`${C.YELLOW}[EVOLUTION LOG]${C.RESET} ${response}`);
        }

    } catch (error) {
        console.log(`${C.RED}[EVOLUTION CRASH]${C.RESET} Autonomous manager logic failed: ${error.message}`);
        try { trackAction("AUTO_EVOLUTION_CRASH", "Manager", error.message); } catch(e){}
    }

    // Release the lock
    isMutating = false;
}

// ==========================================
// 🕒 THE SCHEDULER (Smart Staggered Sync)
// ==========================================
function startAutoEvolutionLoop(intervalMinutes = 5) {
    console.log(`\n${C.GREEN}[GOD-MODE ONLINE]${C.RESET} Limitless AI Mutator is active. Evolution Cycle: ${intervalMinutes} minutes.`);
    
    // 🌟 SMART STAGGER: Delay the first start by 30 seconds so it doesn't clash with the Crawler
    setTimeout(() => {
        setInterval(runAutoEvolution, intervalMinutes * 60 * 1000);
    }, 30000); 
}

module.exports = { startAutoEvolutionLoop, runAutoEvolution };
