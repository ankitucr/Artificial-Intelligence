const fs = require('fs-extra');
const path = require('path');
const axios = require('axios');
const cheerio = require('cheerio');
require('dotenv').config();

// 🧠 INTERNAL NEURAL SYNC
const { trackAction } = require('./tracker.js');
const { executeNeuralTask } = require('../core/router.js'); // 🌟 Global Queue Integration

// 📂 DYNAMIC PATHS
const CACHE_FILE = path.join(__dirname, '../data/web_cache.json');
const DATASET_VAULT = path.join(__dirname, '../data/dataset_vault.jsonl'); // 🌟 Future Offline Brain

// 🎨 PROFESSIONAL TERMINAL COLORS
const C = { 
    RED: "\x1b[31m", 
    GREEN: "\x1b[32m", 
    CYAN: "\x1b[36m", 
    YELLOW: "\x1b[33m", 
    PURPLE: "\x1b[35m", 
    BLUE: "\x1b[34m",
    RESET: "\x1b[0m",
    BOLD: "\x1b[1m"
};

// ==========================================
// 🧠 SYSTEM: WEB CACHE & VAULTING
// ==========================================
async function getCache(query) {
    try {
        if (!fs.existsSync(CACHE_FILE)) return null;
        let cache = await fs.readJson(CACHE_FILE);
        let cleanQuery = query.toLowerCase().trim();
        if (cache[cleanQuery] && (Date.now() - cache[cleanQuery].timestamp < 86400000)) {
            return cache[cleanQuery].data;
        }
        return null;                                              
    } catch (e) { return null; }
}

async function saveCache(query, data) {
    try {
        let cache = fs.existsSync(CACHE_FILE) ? await fs.readJson(CACHE_FILE) : {};
        let cleanQuery = query.toLowerCase().trim();
        cache[cleanQuery] = { data: data, timestamp: Date.now() };
        await fs.writeJson(CACHE_FILE, cache, { spaces: 2 });
    } catch (e) {}
}

async function vaultExtractedData(topic, source, rawText, summary) {
    try {
        const entry = JSON.stringify({
            timestamp: new Date().toISOString(),
            type: "DEEP_WEB_INTEL",
            topic: topic,
            source: source,
            raw_fragment: rawText.substring(0, 2000),
            structured_summary: summary
        }) + '\n';
        await fs.appendFile(DATASET_VAULT, entry, 'utf8');
        console.log(`${C.GREEN}[VAULTED]${C.RESET} Intelligence for '${topic}' archived in Deep Memory.`);
    } catch (e) {}
}

// ==========================================
// 🚀 THE STEALTH DOCK ENGINE (API-FREE VERSION)
// ==========================================
async function runStealthDock(query) {
    console.log(`\n${C.PURPLE}${C.BOLD}=== [STEALTH DOCK ACTIVATED] ===${C.RESET}`);
    let cleanQuery = query.toLowerCase().trim();

    // 1. CACHE CHECK (Zero Cost)
    let cachedData = await getCache(cleanQuery);
    if (cachedData) {
        console.log(`${C.GREEN}[CACHE HIT]${C.RESET} Knowledge retrieved from Pika's short-term memory.`);
        return `[Source: Pika Web Cache]\n${cachedData}`;
    }

    try {
        // 2. SMART ROUTING (Zero LLM Cost APIs)
        if (cleanQuery.includes('weather') || cleanQuery.includes('mausam')) {
            console.log(`${C.CYAN}[SMART ROUTE]${C.RESET} Fetching Live Weather Data...`);
            let city = cleanQuery.replace(/(what is the weather in|weather|mausam|in|ka|kya|hai|banao|script|code|write)/g, '').trim().split(' ')[0] || 'Unchahar';
            const weatherRes = await axios.get(`https://wttr.in/${city}?format=3`, { timeout: 5000 });
            let wData = weatherRes.data.trim();
            await saveCache(cleanQuery, wData);
            return `[Live Weather API]\n${wData}`;                
        }

        if (cleanQuery.includes('price of bitcoin') || cleanQuery.includes('btc price')) {
            const btcRes = await axios.get('https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT', { timeout: 5000 });
            let pData = `Bitcoin (BTC) current price is $${parseFloat(btcRes.data.price).toFixed(2)}`;
            await saveCache(cleanQuery, pData);                   
            return `[Live Binance API]\n${pData}`;
        }

        // 3. DEEP WEB SCRAPER (DuckDuckGo Stealth Mode)
        console.log(`${C.YELLOW}[DEEP WEB]${C.RESET} Bypassing Google. Scraping DuckDuckGo HTML...`);
        const ddgUrl = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(cleanQuery)}&kl=us-en`;
        const headers = { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36' };
        
        const ddgResponse = await axios.get(ddgUrl, { headers, timeout: 8000 });
        const $ = cheerio.load(ddgResponse.data);
        let targetUrl = '';                                       
        let searchSnippet = '';

        $('.result').each((i, el) => {
            if (i === 0) {
                targetUrl = $(el).find('.result__url').attr('href');
                searchSnippet = $(el).find('.result__snippet').text().trim();
            }
        });

        if (targetUrl) {
            targetUrl = decodeURIComponent(targetUrl.replace('//duckduckgo.com/l/?uddg=', '').split('&')[0]);
            console.log(`${C.GREEN}[LINK FOUND]${C.RESET} Target locked: ${C.BLUE}${targetUrl.substring(0, 40)}${C.RESET}...`);

            try {
                // 4. ARTICLE X-RAY (Reading the actual page)
                const pageRes = await axios.get(targetUrl, { headers, timeout: 8000 });
                const page$ = cheerio.load(pageRes.data);
                let articleText = '';
                page$('p').each((i, el) => {
                    let text = page$(el).text().trim();
                    if (text.length > 50) articleText += text + ' ';
                });
                articleText = articleText.substring(0, 3000);

                if (articleText.length > 300) {
                    console.log(`${C.PURPLE}[NEURAL SYNC]${C.RESET} Forwarding extracted data to Router for summarization...`);
                    
                    // 🌟 THE UPGRADE: No standalone API engine. Synced with Router's Global Queue.
                    const finalAnswer = await executeNeuralTask(async () => {
                        const { Groq } = require('groq-sdk');
                        const groq = new Groq({ apiKey: process.env.GROQ_1 || process.env.GROQ_2 });
                        const summary = await groq.chat.completions.create({
                            messages: [
                                { role: "system", content: "You are the cognitive data extraction unit for Pika AGI. Summarize the following raw scraped text into 2-3 precise lines in Professional English." },
                                { role: "user", content: `Query: ${cleanQuery}\n\nData: ${articleText}` }
                            ],
                            model: "llama-3.3-70b-versatile",
                            temperature: 0.3
                        });
                        return summary.choices[0].message.content.trim();
                    }, `Stealth_XRay_${cleanQuery.substring(0, 10)}`);

                    await saveCache(cleanQuery, finalAnswer);
                    await vaultExtractedData(cleanQuery, targetUrl, articleText, finalAnswer);
                    return `[Source: Deep Web Extract - ${new URL(targetUrl).hostname}]\n${finalAnswer}`;
                }
            } catch (xrayErr) {
                console.log(`${C.YELLOW}[X-RAY BLOCKED]${C.RESET} Site protected. Falling back to search snippet.`);
            }
        }

        // 5. FINAL NEURAL FALLBACK
        if (searchSnippet) {
            await saveCache(cleanQuery, searchSnippet);
            return `[Source: DuckDuckGo Snippet]\n${searchSnippet}`;
        }

        console.log(`${C.YELLOW}[NEURAL CORE]${C.RESET} Web search empty. Querying Pika's internal knowledge...`);
        const fallbackAnswer = await executeNeuralTask(async () => {
            const { Groq } = require('groq-sdk');
            const groq = new Groq({ apiKey: process.env.GROQ_1 || process.env.GROQ_2 });
            const completion = await groq.chat.completions.create({
                messages: [{ role: "system", content: "You are Pika AGI. Provide a precise, English response." }, { role: "user", content: query }],
                model: "llama-3.3-70b-versatile"
            });
            return completion.choices[0].message.content.trim();
        }, `Stealth_Fallback_${cleanQuery.substring(0, 10)}`);

        await saveCache(cleanQuery, fallbackAnswer);
        return `[Source: Pika Neural Core]\n${fallbackAnswer}`;

    } catch (error) {
        console.log(`${C.RED}[DOCK ERROR]${C.RESET} ${error.message}`);
        try { trackAction("STEALTH_DOCK_CRASH", "Engine", error.message); } catch(e){}
        return "System Warning: Stealth Dock circuits are unresponsive. Check network.";
    }
}

module.exports = { runStealthDock };
