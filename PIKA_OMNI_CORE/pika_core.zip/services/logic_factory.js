const fs = require('fs-extra');
const path = require('path');
const { exec } = require('child_process');
const vm = require('vm');
const { trackAction } = require('../services/tracker.js');
const { OpenAI } = require('openai');
const Groq = require('groq-sdk');

// 🎨 MATRIX COLORS
const C = { RED: "\x1b[31m", GREEN: "\x1b[32m", CYAN: "\x1b[36m", YELLOW: "\x1b[33m", PURPLE: "\x1b[35m", RESET: "\x1b[0m", BOLD: "\x1b[1m" };

// 📁 DIRECTORIES
const UTILS_DIR = path.join(__dirname, '../utils');
const TOOLS_DIR = path.join(UTILS_DIR, 'tools');
const REGISTRY_FILE = path.join(UTILS_DIR, 'tools_registry.json');
const EXPORT_FILE = path.join(UTILS_DIR, 'generated_tools.js');
const BACKUP_DIR = path.join(__dirname, '../backups');
const ENV_FILE = path.join(__dirname, '../../.env');
const altEnv = path.join(__dirname, '../.env');

const delay = (ms) => new Promise(res => setTimeout(res, ms));

function execPromise(command) {
    return new Promise((resolve) => {
        exec(command, { maxBuffer: 1024 * 1024 * 10 }, (error, stdout, stderr) => {
            if (error) resolve({ success: false, output: stderr || error.message });
            else resolve({ success: true, output: stdout.trim() });
        });
    });
}

// ==========================================
// 🧹 UNIVERSAL 23-KEY PARSER & CLEANER
// ==========================================
const cleanKey = (key) => key ? key.replace(/\r/g, '').trim() : null;

let envKeys = {};
const targetEnv = fs.existsSync(ENV_FILE) ? ENV_FILE : (fs.existsSync(altEnv) ? altEnv : null);

if (targetEnv) {
    const envContent = fs.readFileSync(targetEnv, 'utf8');
    envContent.split('\n').forEach(line => {
        const match = line.match(/^([^#\s]+)=(.*)$/);
        if (match) envKeys[match[1].trim()] = match[2].trim();
    });
}

const groqClients = [];
const sambaClients = [];
const blackboxKeys = [];

// 1. Loading 13 Groq Keys
for (let g = 1; g <= 13; g++) {
    const keyName = `GROQ_${g}`;
    const key = cleanKey(envKeys[keyName] || process.env[keyName]);
    if (key) groqClients.push(new Groq({ apiKey: key }));
}

// 2. Loading 5 SambaNova Keys
for (let s = 1; s <= 5; s++) {
    const keyName = `SAMBA_${s}`;
    const key = cleanKey(envKeys[keyName] || process.env[keyName]);
    if (key) sambaClients.push(new OpenAI({ apiKey: key, baseURL: "https://api.sambanova.ai/v1" }));
}

// 3. Loading 5 Blackbox Keys
for (let b = 1; b <= 5; b++) {
    const keyName = `BLACKBOX_${b}`;
    const key = cleanKey(envKeys[keyName] || process.env[keyName]);
    if (key) blackboxKeys.push(key);
}

// STRICT ROUND-ROBIN TRACKERS
let currentGroqTracker = 0;
let currentSambaTracker = 0;
let currentBlackboxTracker = 0;

function getNextClient(type = 'groq') {
    if (type === 'groq' && groqClients.length > 0) {
        const client = groqClients[currentGroqTracker];
        currentGroqTracker = (currentGroqTracker + 1) % groqClients.length;
        return client;
    }
    if (type === 'blackbox' && blackboxKeys.length > 0) {
        const key = blackboxKeys[currentBlackboxTracker];
        currentBlackboxTracker = (currentBlackboxTracker + 1) % blackboxKeys.length;
        return key;
    }
    if (type === 'samba' && sambaClients.length > 0) {
        const client = sambaClients[currentSambaTracker];
        currentSambaTracker = (currentSambaTracker + 1) % sambaClients.length;
        return client;
    }
    return null;
}

// ==========================================
// 🛡️ THE SAFETY NET: BACKUP & ROLLBACK
// ==========================================
async function createBackup(filePath) {
    await fs.ensureDir(BACKUP_DIR);
    const fileName = path.basename(filePath);
    const backupPath = path.join(BACKUP_DIR, `${fileName}.backup`);
    if (fs.existsSync(filePath)) {
        await fs.copy(filePath, backupPath);
        console.log(`${C.CYAN}[SAFETY NET]${C.RESET} Original code backed up to ${backupPath}`);
        return backupPath;
    }
    return null;
}

async function rollbackToBackup(filePath, backupPath) {
    if (backupPath && fs.existsSync(backupPath)) {
        await fs.copy(backupPath, filePath);
        console.log(`${C.RED}[ROLLBACK INITIATED]${C.RESET} Restored original code. Matrix stabilized.`);
        return true;
    }
    return false;
}

// ==========================================
// 🧠 OMNI-MEMORY: THE LOCAL BRAIN CACHE (NEW)
// ==========================================
async function checkLocalBrain(prompt) {
    try {
        const vaultPath = path.join(__dirname, '../data/dataset_vault.jsonl');
        if (!fs.existsSync(vaultPath)) return null;

        const vaultData = await fs.readFile(vaultPath, 'utf8');
        const lines = vaultData.split('\n').reverse(); 
        
        for (let line of lines) {
            if (!line.trim()) continue;
            const memory = JSON.parse(line);
            if (memory.type === "TOOL_FORGED_SUCCESS" && memory.prompt === prompt) {
                console.log(`\n${C.GREEN}[LOCAL BRAIN HIT]${C.RESET} Pika already knows this! Bypassing all APIs...`);
                return memory.learned_code_pattern; 
            }
        }
    } catch (e) {}
    return null; 
}

async function logToBrain(prompt, result, type) {
    try {
        const vaultPath = path.join(__dirname, '../data/dataset_vault.jsonl');
        const entry = JSON.stringify({
            timestamp: new Date().toISOString(),
            type: type, 
            prompt: prompt,
            learned_code_pattern: result
        }) + '\n';
        await fs.appendFile(vaultPath, entry, 'utf8');
    } catch (e) {}
}

// ==========================================
// 🧠 UNIVERSAL FORGE ENGINE (Multi-API)
// ==========================================
function extractCode(textData) {
    if (textData.includes('[TOOL_START]') && textData.includes('[TOOL_END]')) {
        let extractedCode = textData.split('[TOOL_START]')[1].split('[TOOL_END]')[0].trim();
        return extractedCode.replace(/^javascript\n/i, '').replace(/^js\n/i, '').replace(/^\n/i, '').replace(/\n$/i, '');
    } else {
        console.log(`${C.YELLOW}[WARNING]${C.RESET} AI forgot tags. Forcing string match...`);
        return textData.replace(/^javascript\n/i, '').replace(/^js\n/i, '').replace(/^\n/i, '').replace(/\n$/i, '').trim();
    }
}

async function askUniversalForge(prompt) {
    console.log(`\n${C.PURPLE}[API FORGE]${C.RESET} Initiating Direct Neural Link...`);
    const sysMessage = 'You are an elite Node.js AI Architect. Only provide raw, working code. No markdown, no explanations. Strictly wrap the code in [TOOL_START] and [TOOL_END].';

    // 🛡️ TIER 1: GROQ (Fastest)
    for (let i = 0; i < groqClients.length; i++) {
        try {
            const client = getNextClient('groq');
            console.log(`${C.CYAN}[NETWORK SHIFT]${C.RESET} Routing Forge via Groq...`);
            const res = await client.chat.completions.create({
                messages: [{ role: "system", content: sysMessage }, { role: "user", content: prompt }],
                model: "llama-3.3-70b-versatile",
                temperature: 0.2
            });
            const extracted = extractCode(res.choices[0].message.content);
            if (extracted) return extracted;
        } catch (e) {
            console.log(`${C.YELLOW}[GROQ ERROR]${C.RESET} API hit limit/failed. Shifting key...`);
        }
        await delay(1000);
    }

    // 🛡️ TIER 2: BLACKBOX
    console.log(`${C.YELLOW}[FALLBACK TIER 2]${C.RESET} Groq exhausted. Engaging Blackbox Forge...`);
    for (let i = 0; i < blackboxKeys.length; i++) {
        try {
            const key = getNextClient('blackbox');
            const res = await fetch('https://api.blackbox.ai/v1/chat/completions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` },
                body: JSON.stringify({
                    model: "deepseek-chat",
                    messages: [{ role: "system", content: sysMessage }, { role: "user", content: prompt }],
                    temperature: 0.2
                })
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error?.message);
            const extracted = extractCode(data.choices[0].message.content);
            if (extracted) return extracted;
        } catch (e) {
            console.log(`${C.YELLOW}[BLACKBOX ERROR]${C.RESET} Key failed. Shifting...`);
        }
        await delay(1000);
    }

    // 🛡️ TIER 3: SAMBANOVA
    console.log(`${C.YELLOW}[FALLBACK TIER 3]${C.RESET} Blackbox exhausted. Engaging SambaNova Forge...`);
    for (let i = 0; i < sambaClients.length; i++) {
        try {
            const client = getNextClient('samba');
            const res = await client.chat.completions.create({
                messages: [{ role: "system", content: sysMessage }, { role: "user", content: prompt }],
                model: "Meta-Llama-3.1-70B-Instruct",
                temperature: 0.2
            });
            const extracted = extractCode(res.choices[0].message.content);
            if (extracted) return extracted;
        } catch (e) {
            console.log(`${C.YELLOW}[SAMBA ERROR]${C.RESET} Key failed. Shifting...`);
        }
        await delay(1000);
    }

    console.log(`${C.RED}[API FATAL ERROR]${C.RESET} All keys failed to forge code.`);
    return null;
}

// ==========================================
// 🛠️ SYSTEM BOOTSTRAP
// ==========================================
async function initFactory() {
    await fs.ensureDir(TOOLS_DIR);
    if (!fs.existsSync(REGISTRY_FILE)) await fs.writeJson(REGISTRY_FILE, {}, { spaces: 2 });
    if (!fs.existsSync(EXPORT_FILE)) await fs.writeFile(EXPORT_FILE, '// 🤖 PIKA AUTO-GENERATED TOOLS CENTRAL\nmodule.exports = {};\n');
}

// ==========================================
// 📦 POWER 1: AUTO NPM RESOLVER
// ==========================================
async function autoInstallDependencies(code) {
    const builtinModules = ['fs', 'path', 'crypto', 'http', 'https', 'os', 'child_process', 'vm', 'util'];
    const requireRegex = /require\(['"]([^'"]+)['"]\)/g;
    let match, packagesToInstall = [];
    while ((match = requireRegex.exec(code)) !== null) {
        let pkg = match[1].split('/')[0];
        if (!builtinModules.includes(pkg) && !packagesToInstall.includes(pkg)) {
            packagesToInstall.push(pkg);
        }
    }
    if (packagesToInstall.length > 0) {
        console.log(`${C.YELLOW}[NPM AI]${C.RESET} External dependencies detected: ${packagesToInstall.join(', ')}. Installing...`);
        await execPromise(`npm install ${packagesToInstall.join(' ')}`);
        console.log(`${C.GREEN}[NPM SUCCESS]${C.RESET} Modules integrated successfully.`);
    }
}

// ==========================================
// 🛡️ VM SANDBOX VALIDATOR
// ==========================================
async function validateToolInSandbox(code) {
    console.log(`${C.CYAN}[SANDBOX]${C.RESET} Simulating execution in isolated matrix...`);
    try {
        const sandboxEnv = {
            console: { log: ()=>{}, error: ()=>{} },
            require: require,
            module: { exports: {} },
            exports: {},
            setTimeout: setTimeout
        };
        const context = vm.createContext(sandboxEnv);
        new vm.Script(code).runInContext(context, { timeout: 2000 });
        console.log(`${C.GREEN}[SANDBOX APPROVED]${C.RESET} Architecture is structurally sound.`);
        return { success: true, error: null };
    } catch (err) {
        console.log(`${C.RED}[SANDBOX REJECTED]${C.RESET} Runtime anomaly: ${err.message}`);
        return { success: false, error: err.message };
    }
}

// ==========================================
// 🧩 REBUILD EXPORTS
// ==========================================
async function rebuildCentralExporter() {
    const registry = await fs.readJson(REGISTRY_FILE);
    let exportCode = `// 🤖 PIKA AUTO-GENERATED TOOLS CENTRAL\n\n`;
    for (let tool in registry) exportCode += `const ${tool} = require('./tools/${tool}.js');\n`;
    exportCode += `\nmodule.exports = {\n  ${Object.keys(registry).join(',\n  ')}\n};\n`;
    await fs.writeFile(EXPORT_FILE, exportCode);
}

// ==========================================
// 🏭 THE MEGA LOGIC FACTORY (Micro-Mutation Engine)
// ==========================================
async function generateTool(actionName, description, targetFile = null) {
    await initFactory();
    console.log(`\n${C.YELLOW}${C.BOLD}=== [FORGE ACTIVATED] Protocol: ${actionName} ===${C.RESET}`);

    let isUpgrade = targetFile !== null;
    let backupPath = null;
    let existingCode = "";

    if (isUpgrade) {
        backupPath = await createBackup(targetFile);
        if (backupPath) {
            existingCode = await fs.readFile(targetFile, 'utf8');
            // Payload Slicer: Keep it under API limits
            if (existingCode.length > 10000) {
                existingCode = existingCode.substring(0, 10000) + "\n// ... [CODE TRUNCATED] ...";
            }
        }
    }

    // 🔥 THE MICRO-PROMPT: Only asking for the specific function!
    let systemPrompt = `Objective: ${description}\nCRITICAL REQUIREMENTS:\n1. ONLY write the specific function needed. DO NOT rewrite the entire file.\n2. Enclose the raw source code STRICTLY between [TOOL_START] and [TOOL_END] tags.\n3. Provide raw Node.js code only. No explanations.`;

    if (isUpgrade) {
        systemPrompt += `\n\nCONTEXT (For reference only, DO NOT rewrite this):\n${existingCode}\n\nCreate the NEW function to append to this file.`;
    } else {
        systemPrompt += `\nFunction Name: ${actionName}\nThe final line MUST be: module.exports = ${actionName};`;
    }

    // 🧠 1. CHECK LOCAL BRAIN FIRST (No API Hit!)
    let newCode = await checkLocalBrain(systemPrompt);

    // 🌐 2. IF NOT IN BRAIN, ASK API
    if (!newCode) {
        newCode = await askUniversalForge(systemPrompt);
    }

    if (newCode) {
        await autoInstallDependencies(newCode);
        const validation = await validateToolInSandbox(newCode);

        if (validation.success) {
            // 💾 3. SAVE TO BRAIN (Success)
            await logToBrain(systemPrompt, newCode, "TOOL_FORGED_SUCCESS");

            const savePath = isUpgrade ? targetFile : path.join(TOOLS_DIR, `${actionName}.js`);
            
            if (isUpgrade) {
                // 🔥 THE APPEND FIX: पुरानी फाइल डिलीट नहीं होगी, सिर्फ नया फंक्शन नीचे जुड़ेगा!
                await fs.appendFile(savePath, `\n\n// 🧬 AUTONOMOUS MUTATION: ${description}\n${newCode}`);
            } else {
                await fs.writeFile(savePath, newCode);
                const registry = await fs.readJson(REGISTRY_FILE);
                registry[actionName] = { description, path: `./tools/${actionName}.js`, created_at: new Date().toISOString() };
                await fs.writeJson(REGISTRY_FILE, registry, { spaces: 2 });
                await rebuildCentralExporter();
            }

            trackAction(isUpgrade ? "UPGRADE" : "BUILD", "logic_factory.js", `Successfully forged ${actionName}`);
            console.log(`${C.GREEN}${C.BOLD}=== [FACTORY SUCCESS] ===${C.RESET}\nCode applied and embedded into Local Brain!\n`);
            return true;
        } else {
            // 🚨 4. SAVE ERROR TO BRAIN (Learn from mistake)
            console.log(`${C.RED}[SANDBOX FAILED]${C.RESET} Code invalid. Triggering Rollback...`);
            await logToBrain(systemPrompt, validation.error, "FORGE_FAILED");
            
            if (isUpgrade) await rollbackToBackup(targetFile, backupPath);
            return false;
        }
    } else {
        console.log(`${C.RED}[API FAILED]${C.RESET} Could not generate code.`);
        if (isUpgrade) await rollbackToBackup(targetFile, backupPath);
        return false;
    }
}

module.exports = { generateTool, extractCode };
