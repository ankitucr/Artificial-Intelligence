const fs = require('fs-extra');
const path = require('path');

// 📂 DYNAMIC PATHS
const LOG_DIR = path.join(__dirname, '../logs');
const ARCHIVE_DIR = path.join(LOG_DIR, 'archives');
const LOG_FILE = path.join(LOG_DIR, 'pika_live_matrix.jsonl');
const DATASET_VAULT = path.join(__dirname, '../data/dataset_vault.jsonl'); // 🌟 Synced with Offline LLM Dream

// 🎨 PROFESSIONAL MATRIX COLORS
const C = { 
    RED: "\x1b[31m", 
    GREEN: "\x1b[32m", 
    CYAN: "\x1b[36m", 
    YELLOW: "\x1b[33m", 
    PURPLE: "\x1b[35m", 
    BLUE: "\x1b[34m",
    RESET: "\x1b[0m",
    BOLD: "\x1b[1m"
};

// ==========================================
// ⚙️ TELEMETRY ENGINE INITIALIZATION
// ==========================================
fs.ensureDirSync(LOG_DIR);
fs.ensureDirSync(ARCHIVE_DIR);

// ==========================================
// 🛡️ AUTO-ROTATION & ARCHIVING (Crash Prevention)
// ==========================================
const MAX_LOG_SIZE_BYTES = 5 * 1024 * 1024; // 5MB Cap

async function checkAndRotateLogs() {
    try {
        if (await fs.pathExists(LOG_FILE)) {
            const stats = await fs.stat(LOG_FILE);
            if (stats.size >= MAX_LOG_SIZE_BYTES) {
                const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
                const archivePath = path.join(ARCHIVE_DIR, `matrix_archive_${timestamp}.jsonl`);
                await fs.rename(LOG_FILE, archivePath);
                console.log(`\n${C.CYAN}[TELEMETRY SHIFT]${C.RESET} Log limit reached. Archive created: ${C.BLUE}${path.basename(archivePath)}${C.RESET}`);
            }
        }
    } catch (error) {
        // Silent fail to prevent main thread crash
    }
}

// ==========================================
// ⚡ HIGH-PERFORMANCE MEMORY BUFFER
// ==========================================
let logBuffer = [];
const MAX_BUFFER_SIZE = 10; 
let isFlushing = false;

async function flushBufferToDisk() {
    if (isFlushing || logBuffer.length === 0) return;
    isFlushing = true;

    try {
        await checkAndRotateLogs();
        const batchToWrite = logBuffer.join('');
        logBuffer = [];
        await fs.appendFile(LOG_FILE, batchToWrite, 'utf8');
    } catch (error) {
        console.error(`${C.RED}[BUFFER ERROR]${C.RESET} ${error.message}`);
    } finally {
        isFlushing = false;
    }
}

// Force flush every 30s to prevent data loss
setInterval(flushBufferToDisk, 30000);

// ==========================================
// 🧠 NEURAL TELEMETRY (The Nervous System)
// ==========================================
/**
 * @param {string} category - INFO, ERROR, MUTATION, SYSTEM, CRAWLER
 * @param {string} action - The specific event name
 * @param {object} details - Metadata or context
 * @param {boolean} vault - Should this go to the long-term dataset vault?
 */
async function trackAction(category, action, details = {}, vault = false) {
    try {
        const now = new Date();
        const timestamp = now.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });

        const logObject = {
            timestamp: timestamp,
            category: category.toUpperCase(),
            action: action,
            details: details,
            system_vitals: {
                ram_usage: (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2) + " MB"
            }
        };

        const logEntry = JSON.stringify(logObject) + '\n';
        logBuffer.push(logEntry);

        // 🎨 PROFESSIONAL LOGGING BASED ON CATEGORY
        let color = C.CYAN;
        if (category === 'ERROR') color = C.RED;
        if (category === 'MUTATION') color = C.PURPLE;
        if (category === 'SYSTEM') color = C.YELLOW;
        if (category === 'CRAWLER') color = C.GREEN;

        console.log(`${color}[${category}]${C.RESET} ${action} -> ${C.BLUE}${typeof details === 'string' ? details : 'Processing data'}${C.RESET}`);

        // 🌟 DATASET VAULTING (Self-Learning)
        if (vault) {
            const vaultEntry = JSON.stringify({
                timestamp: timestamp,
                type: "NEURAL_LEARNING",
                event: action,
                data: details
            }) + '\n';
            await fs.appendFile(DATASET_VAULT, vaultEntry, 'utf8');
        }

        if (logBuffer.length >= MAX_BUFFER_SIZE) {
            flushBufferToDisk();
        }

    } catch (error) {
        // Atomic fail-safe
    }
}

module.exports = { trackAction };
