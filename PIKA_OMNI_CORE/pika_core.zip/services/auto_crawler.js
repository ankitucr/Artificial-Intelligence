const fs = require('fs-extra');
const path = require('path');
const Groq = require('groq-sdk');
const { OpenAI } = require('openai');
require('dotenv').config();

const { readMemory, saveMemory } = require('../core/memory_manager.js');
const { runStealthDock } = require('./stealth_dock.js');
const { executeNeuralTask } = require('../core/router.js'); // 🌟 Synced with Router's Main Gate

// ==========================================
// 🎨 PROFESSIONAL TERMINAL COLORS
// ==========================================
const C = {
    CYAN: "\x1b[38;5;51m",     // For Processes & Crawler
    PURPLE: "\x1b[38;5;213m",   // For Neural/Brain activities
    GREEN: "\x1b[38;5;82m",     // For Success & Vaulting
    RED: "\x1b[38;5;196m",      // For Errors & Fails
    YELLOW: "\x1b[38;5;226m",   // For Warnings & Delays
    BLUE: "\x1b[38;5;45m",      // For File Names
    RESET: "\x1b[0m",
    BOLD: "\x1b[1m"
};

const DATASET_VAULT = path.join(__dirname, '../data/dataset_vault.jsonl');

// ==========================================
// 🔄 TEMPORARY API ENGINE (Will move to Router later)
// ==========================================
const sambaClients = [];
const groqClients = [];

let s = 1;
while(process.env[`SAMBA_${s}`]) {
    sambaClients.push(new OpenAI({ apiKey: process.env[`SAMBA_${s}`].trim(), baseURL: "https://api.sambanova.ai/v1" }));
    s++;
}

let g = 1;
while(process.env[`GROQ_${g}`]) {
    groqClients.push(new Groq({ apiKey: process.env[`GROQ_${g}`].trim() }));
    g++;
}

let currentSambaTracker = Math.max(0, sambaClients.length - 1);
let currentGroqTracker = Math.max(0, groqClients.length - 1);

function getSamba() {
    if (sambaClients.length === 0) return null;
    const client = sambaClients[currentSambaTracker];
    currentSambaTracker = (currentSambaTracker - 1 + sambaClients.length) % sambaClients.length;
    return client;
}

function getGroq() {
    if (groqClients.length === 0) return null;
    const client = groqClients[currentGroqTracker];
    currentGroqTracker = (currentGroqTracker - 1 + groqClients.length) % groqClients.length;
    return client;
}

// ==========================================
// 🧠 LOCAL LLM DATASET BUILDER
// ==========================================
async function vaultRawData(topic, text) {
    try {
        const entry = JSON.stringify({ 
            timestamp: new Date().toISOString(), 
            type: "CRAWLER_RAW_DATA", 
            topic: topic, 
            content: text.substring(0, 5000) // Conserving space
        }) + '\n';
        await fs.appendFile(DATASET_VAULT, entry, 'utf8');
        console.log(`${C.GREEN}[DATA VAULT]${C.RESET} Raw data for '${C.BLUE}${topic}${C.RESET}' archived for future offline LLM training.`);
    } catch (e) {
        console.log(`${C.RED}[DATA VAULT ERROR]${C.RESET} Could not save raw data.`);
    }
}

// ==========================================
// 🧠 NEURAL KNOWLEDGE EXTRACTION
// ==========================================
async function structureKnowledge(topic, rawText) {
    console.log(`${C.PURPLE}[NEURAL CORE]${C.RESET} Structuring intelligence for: ${C.YELLOW}${topic}${C.RESET}`);

    const prompt = `You are the autonomous learning engine of Pika AGI.
Analyze the following raw internet text about the topic: "${topic}".
Extract the core intelligence and structure it EXACTLY in this JSON format. Ignore conversational text.
{
  "definition": "A clear explanation of the technology in professional English.",
  "core_concepts": ["tech term 1", "tech term 2"],
  "use_case": "Real-world application in English."
}
CRITICAL: Return ONLY the JSON object.
Raw Text: ${rawText}`;

    try {
        // 🌟 Synced with Router's Gate to prevent crashes
        let jsonStr = await executeNeuralTask(async () => {
            const client = getGroq() || getSamba();
            if(!client) throw new Error("No API Keys available.");

            const response = await client.chat.completions.create({
                messages: [{ role: "system", content: prompt }],
                model: "llama-3.3-70b-versatile", // Using fast model for extraction
                temperature: 0.1,
                max_tokens: 500
            });
            return response.choices[0].message.content.trim();
        }, `Crawler_Extract_${topic.substring(0, 10)}`);

        const jsonMatch = jsonStr.match(/\{[\s\S]*\}/);
        if (jsonMatch) return JSON.parse(jsonMatch[0]);
        throw new Error("Invalid JSON format from Neural Node.");

    } catch (err) {
        console.log(`${C.RED}[EXTRACTION FAILED]${C.RESET} Neural Core Error: ${err.message}`);
        return null;
    }
}

// ==========================================
// 🚀 THE MAIN CRAWLER ENGINE
// ==========================================
let baseInterval = 2;
let currentInterval = baseInterval;
let crawlerTimer = null;

async function startAutonomousEvolution() {
    if (!global.isSleeping) {
        // Silent pause when Architect is active
        return;
    }

    console.log(`\n${C.CYAN}[AUTO CRAWLER]${C.RESET} ${C.BOLD}Initiating Extraction Sequence...${C.RESET}`);

    let deepK = await readMemory('deep_knowledge.json').catch(() => ({}));
    let pending = await readMemory('pending_learning.json').catch(() => []);

    if (!Array.isArray(pending) || pending.length === 0) {
        console.log(`${C.YELLOW}[IDLE]${C.RESET} Curiosity Queue is empty. Waiting for new topics in ${C.BLUE}pending_learning.json${C.RESET}.`);
        return; 
    }

    let currentTopic = pending.shift();

    if (deepK[currentTopic]) {
        console.log(`${C.PURPLE}[SKIP]${C.RESET} Memory already contains: ${currentTopic}`);
        await saveMemory('pending_learning.json', pending);
        return;
    }

    console.log(`${C.CYAN}[HUNTING]${C.RESET} Web Scraper targeting: ${C.YELLOW}${currentTopic}${C.RESET}`);
    
    // Scrape data
    let knowledgeText = await runStealthDock(currentTopic);
    const isApiError = knowledgeText && (knowledgeText.startsWith('Error') || knowledgeText.includes('429'));

    if (knowledgeText && !isApiError) {
        currentInterval = baseInterval; // Reset speed on success

        // 🌟 Save raw data for Future Local LLM
        await vaultRawData(currentTopic, knowledgeText);

        // Extract JSON structure
        let structuredData = await structureKnowledge(currentTopic, knowledgeText);
        
        if (structuredData) {
            structuredData.learned_on = new Date().toISOString();
            deepK[currentTopic] = structuredData;

            let newConcepts = structuredData.core_concepts || [];
            let addedCount = 0;

            if (Array.isArray(newConcepts)) {
                newConcepts.forEach(concept => {
                    if (concept && typeof concept === 'string' && concept.length > 2) {
                        if (!deepK[concept] && !pending.includes(concept)) {
                            pending.push(concept);
                            addedCount++;
                        }
                    }
                });
            }

            console.log(`${C.GREEN}[SUCCESS]${C.RESET} Intelligence integrated into ${C.BLUE}deep_knowledge.json${C.RESET}`);
            console.log(`${C.PURPLE}[EXPANSION]${C.RESET} ${addedCount} new child concepts added to queue.`);

            await saveMemory('deep_knowledge.json', deepK);
            await saveMemory('pending_learning.json', pending);
        } else {
            console.log(`${C.YELLOW}[CORRUPT DATA]${C.RESET} Dropping topic: ${currentTopic}`);
            await saveMemory('pending_learning.json', pending);
        }

    } else {
        console.log(`${C.RED}[NETWORK/LIMIT ERROR]${C.RESET} Stealth Dock failed for: ${currentTopic}`);

        if (isApiError) {
            currentInterval = Math.min(currentInterval * 2, 10); // Max delay 10 mins
            console.log(`${C.YELLOW}[THROTTLE]${C.RESET} API Limit hit. Extending cooldown to ${currentInterval} minutes.`);
            pending.unshift(currentTopic); // Put back at the start of queue
            await saveMemory('pending_learning.json', pending);
        } else {
            // Irrelevant or dead topic
            await saveMemory('pending_learning.json', pending);
        }
    }
}

// ==========================================
// 🕒 THE RECURSIVE DYNAMIC LOOP
// ==========================================
function loopStep() {
    startAutonomousEvolution().finally(() => {
        crawlerTimer = setTimeout(loopStep, currentInterval * 60 * 1000);
    });
}

function runInfiniteLoop(intervalMinutes) {
    baseInterval = intervalMinutes;
    currentInterval = baseInterval;
    console.log(`\n${C.GREEN}[SYSTEM READY]${C.RESET} Auto-Crawler Prime Sequence online. Interval: ${baseInterval} min.`);
    loopStep();
}

process.on('unhandledRejection', (reason) => {
    console.log(`${C.RED}[CRAWLER GLITCH]${C.RESET} Unhandled Promise: ${reason}`);
});

process.on('uncaughtException', (err) => {
    console.log(`${C.RED}[CRAWLER CRASH]${C.RESET} Exception: ${err.message}`);
});

module.exports = { startAutonomousEvolution, runInfiniteLoop };
