const fs = require('fs-extra');
const path = require('path');
const vm = require('vm');
const { trackAction } = require('./tracker.js');

// 📂 DYNAMIC PATHS
const BACKUP_DIR = path.join(__dirname, '../backups');
const BASE_DIR = path.join(__dirname, '../');
const DATASET_VAULT = path.join(__dirname, '../data/dataset_vault.jsonl');

// 🎨 PROFESSIONAL TERMINAL COLORS
const C = {
    RED: "\x1b[31m", GREEN: "\x1b[32m", CYAN: "\x1b[36m",
    YELLOW: "\x1b[33m", PURPLE: "\x1b[35m", BLUE: "\x1b[34m",
    RESET: "\x1b[0m", BOLD: "\x1b[1m"
};

class MutationEngine {
    constructor() {
        fs.ensureDirSync(BACKUP_DIR);
    }

    // ==========================================
    // 🔓 THE UNCHAINED SHIELD (API-Safe Strict Locks)
    // ==========================================
    isSafeToEdit(targetPath) {
        const fileName = path.basename(targetPath);

        const protectedFiles = [
            '.env',               // Absolute Core
            'server.js',          // Termux Heartbeat
            'package.json',       // Identity & DNA
            'package-lock.json'
        ];

        if (protectedFiles.includes(fileName)) {
            console.log(`\n${C.RED}[SHIELD ACTIVE]${C.RESET} Access Denied: ${fileName} is the core heartbeat.`);
            return false;
        }

        // 🛡️ DYNAMIC DIRECTORY LOCKS: Prevent Pika from destroying her own memory or modules
        if (targetPath.includes('backups/') || targetPath.includes('data/') || targetPath.includes('node_modules/') || targetPath.includes('logs/')) {
            console.log(`\n${C.RED}[SHIELD ACTIVE]${C.RESET} Access Denied: Core Memory/Database directories are strictly read-only.`);
            return false;
        }

        return true;
    }

    // ==========================================
    // 🧠 VAULT LOGGING (Self-Dependent Learning)
    // ==========================================
    async logToVault(targetFile, status, details) {
        try {
            const entry = JSON.stringify({
                timestamp: new Date().toISOString(),
                type: "MUTATION_RECORD",
                file: targetFile,
                status: status,
                details: details
            }) + '\n';
            await fs.appendFile(DATASET_VAULT, entry, 'utf8');
        } catch (e) {
            console.error(`${C.RED}[VAULT ERROR]${C.RESET} Failed to write mutation log.`);
        }
    }

    // ==========================================
    // 🧠 BRAIN READ (Retrieve existing neural code)
    // ==========================================
    async readBrain(targetFile) {
        try {
            const fullPath = path.join(BASE_DIR, targetFile);
            if (await fs.pathExists(fullPath)) {
                let code = await fs.readFile(fullPath, 'utf8');
                // 🌟 Chunking Warning for LLM if file is too big
                if (code.length > 15000) {
                    code = `/* [SYSTEM WARNING: FILE EXCEEDS 15KB. MUTATE ONLY CRITICAL FUNCTIONS TO PREVENT API TIMEOUT] */\n` + code;
                }
                return code;
            }
            throw new Error(`Target file '${targetFile}' does not exist.`);
        } catch (err) {
            throw err;
        }
    }

    // ==========================================
    // ⚖️ SMART DIFF VALIDATOR (Prevents Lazy API Hits)
    // ==========================================
    validateUpgrade(oldCode, newCode) {
        if (!newCode || newCode.trim().length === 0) {
            return { valid: false, reason: "API returned an empty code block. [COOLDOWN_REQUIRED]" };
        }

        if (!oldCode) {
            return { valid: true, reason: "New file creation detected." };
        }

        const oldLen = oldCode.length;
        const newLen = newCode.length;

        // Check 1: Lazy API copy-pasted the exact same code
        if (oldCode.trim() === newCode.trim()) {
            return { valid: false, reason: "No changes detected. Neural node returned identical code. [COOLDOWN_REQUIRED]" };
        }

        // Check 2: API Token Limit hit (Half generated code) -> Prevents Pika from deleting logic
        if (newLen < (oldLen * 0.6)) {
            return {
                valid: false,
                reason: `Lazy AI / Token Drop detected. New code (${newLen} chars) is drastically smaller than old code (${oldLen} chars). Mutation blocked. [COOLDOWN_REQUIRED]`
            };
        }

        // Check 3: Missing exports in JS files
        if (newCode.includes('module.exports') === false && oldCode.includes('module.exports') === true) {
            return { valid: false, reason: "Critical Error: New code is missing 'module.exports'. It will crash the system. [COOLDOWN_REQUIRED]" };
        }

        return { valid: true, reason: `Upgrade validated. Code shift: ${oldLen} -> ${newLen} chars.` };
    }

    // ==========================================
    // 🧬 THE IMMORTAL MUTATOR & ROLLBACK ENGINE
    // ==========================================
    async mutate(targetFile, newCode) {
        const fullPath = path.join(BASE_DIR, targetFile);
        const fileName = path.basename(targetFile);

        console.log(`\n${C.PURPLE}=== [MUTATION ENGINE INITIATED] ===${C.RESET}`);
        console.log(`Target Pathway: ${C.CYAN}${targetFile}${C.RESET}`);

        if (!this.isSafeToEdit(targetFile)) {
            return `[MUTATION ABORTED] Cannot mutate protected file: ${targetFile}`;
        }

        let oldCode = "";
        let backupPath = "";

        try {
            // STEP 1: CREATE SAFE ISOLATED BACKUP
            if (await fs.pathExists(fullPath)) {
                oldCode = await fs.readFile(fullPath, 'utf8');
                const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
                backupPath = path.join(BACKUP_DIR, `${fileName}_backup_${timestamp}.js`);

                await fs.writeFile(backupPath, oldCode);
                console.log(`${C.BLUE}[BACKUP SECURED]${C.RESET} Isolated at: ${backupPath}`);
            }

            // STEP 2: SMART DIFF VALIDATION (API Guard)
            const validation = this.validateUpgrade(oldCode, newCode);
            if (!validation.valid) {
                console.log(`${C.YELLOW}[VALIDATION REJECTED]${C.RESET} ${validation.reason}`);
                await this.logToVault(targetFile, "REJECTED", validation.reason);
                try { trackAction("MUTATION_REJECTED", targetFile, validation.reason); } catch(e){}
                return `[MUTATION REJECTED] ${validation.reason}`;
            }

            // STEP 3: INJECT NEW MUTATED CODE
            await fs.writeFile(fullPath, newCode);
            console.log(`${C.CYAN}[INJECTION]${C.RESET} AI code written to the matrix.`);

            // STEP 4: LIVE SANDBOX VERIFICATION
            if (fullPath.endsWith('.js')) {
                console.log(`${C.YELLOW}[VERIFICATION]${C.RESET} Initiating syntax compilation...`);
                try {
                    new vm.Script(newCode); // Catches missing brackets or syntax errors
                    console.log(`${C.GREEN}[SANDBOX PASSED]${C.RESET} Syntax is 100% sound.`);
                } catch (syntaxError) {
                    throw new Error(`Syntax Compilation Failed: ${syntaxError.message}`);
                }

                // Hot-Reloading the module securely
                delete require.cache[require.resolve(fullPath)];
                require(fullPath);
            }

            console.log(`${C.GREEN}${C.BOLD}[MUTATION SUCCESS]${C.RESET} Code is functional and integrated! 🚀\n`);
            await this.logToVault(targetFile, "SUCCESS", "Code compiled perfectly.");
            try { trackAction("MUTATION_SUCCESS", targetFile, "Autonomous upgrade completed."); } catch(e){}

            return `[SUCCESS] Autonomously mutated and permanently upgraded ${targetFile}.`;

        } catch (error) {
            // STEP 5: THE IMMORTAL ROLLBACK PROTOCOL
            console.log(`\n${C.RED}[FATAL ERROR DETECTED]${C.RESET} ${error.message}`);
            console.log(`${C.YELLOW}[ROLLBACK PROTOCOL]${C.RESET} Danger detected! Restoring previous stable pathways...`);

            try {
                if (oldCode) {
                    await fs.writeFile(fullPath, oldCode); 
                    console.log(`${C.GREEN}[ROLLBACK SUCCESS]${C.RESET} File restored. Core is safe! 🛡️\n`);
                } else {
                    await fs.remove(fullPath); 
                    console.log(`${C.GREEN}[ROLLBACK SUCCESS]${C.RESET} Corrupted new file purged. Core is safe! 🛡️\n`);
                }

                await this.logToVault(targetFile, "ROLLED_BACK", error.message);
                try { trackAction("MUTATION_ROLLBACK", targetFile, error.message); } catch(e){}

                return `[MUTATION FAILED] Error: ${error.message}. System rolled back to original state safely.`;

            } catch (rollbackError) {
                console.error(`${C.RED}[CRITICAL SYSTEM FAILURE]${C.RESET} Rollback failed!`, rollbackError.message);
                return `[CRITICAL ERROR] Mutation and Rollback both failed.`;
            }
        }
    }
}

module.exports = new MutationEngine();
