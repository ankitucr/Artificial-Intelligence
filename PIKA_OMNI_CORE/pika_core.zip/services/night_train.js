const { startAutonomousEvolution } = require('./auto_crawler.js'); // Extraction
const { startFeeder } = require('./feeder.js');                   // Digestion
const { runAutoEvolution } = require('./autonomous_mutator.js');   // Evolution                                                     
const { trackAction } = require('./tracker.js');
                                                                  
// 🎨 PROFESSIONAL MATRIX COLORS
const C = {                                                           
    CYAN: "\x1b[38;5;51m",
    PURPLE: "\x1b[38;5;213m",                                         
    GREEN: "\x1b[38;5;82m",
    RED: "\x1b[38;5;196m",                                            
    YELLOW: "\x1b[38;5;226m",
    BLUE: "\x1b[38;5;45m",
    RESET: "\x1b[0m",
    BOLD: "\x1b[1m"                                               
};                                                                

async function startNightTrain() {
    if (!global.isSleeping) return; // Exit if user is active     
    console.log(`\n${C.CYAN}${C.BOLD}=== [NIGHT TRAIN INITIATED] ===${C.RESET}`);
    console.log(`${C.PURPLE}[REM SLEEP]${C.RESET} Pika's neural pathways are now in optimization mode.`);

    try { trackAction("SYSTEM", "Night Train Started", "REM cycle orchestration active.", true); } catch(e){}

    try {
        let cycleCount = 0;                                       
        // INFINITE EVOLUTION LOOP: Runs while Pika is in sleep mode
        while (global.isSleeping) {                                           
            cycleCount++;
            console.log(`\n${C.PURPLE}${C.BOLD}--- [REM CYCLE #${cycleCount}] ---${C.RESET}`);
                                                                              
            // ---------------------------------------------------------
            // 🕸️ PHASE 1: CRAWLER (The Hunt)
            // ---------------------------------------------------------
            if (global.isSleeping) {
                console.log(`${C.CYAN}[PHASE 1]${C.RESET} Initiating Autonomous Knowledge Extraction...`);
                await startAutonomousEvolution().catch(e => {});                             
            }

            // ---------------------------------------------------------
            // 🧠 PHASE 2: FEEDER (The Digestion)
            // ---------------------------------------------------------                                                                        
            if (global.isSleeping) {                                              
                console.log(`${C.YELLOW}[PHASE 2]${C.RESET} Synthesizing raw data into Neural Code Vault...`);                                      
                await startFeeder().catch(e => {});                                          
            }

            // ---------------------------------------------------------
            // 🧬 PHASE 3: MUTATOR (The Evolution)                            
            // ---------------------------------------------------------                                                                        
            if (global.isSleeping) {
                console.log(`${C.GREEN}[PHASE 3]${C.RESET} Executing God-Mode Architectural Upgrades...`);                                          
                await runAutoEvolution().catch(e => {});                                     
            }                                                                                                                                   

            // ---------------------------------------------------------                                                                        
            // ⚡ SMART PACING (Neural Cool-down: 1 MINUTE)
            // ---------------------------------------------------------                                                                        
            console.log(`\n${C.BLUE}[SYNC]${C.RESET} Cycle #${cycleCount} complete. Cooling down for 1 minute...`);

            // 🌟 Non-blocking wait for 1 Minute (600 iterations of 100ms)
            for(let i = 0; i < 600; i++) {
                if (!global.isSleeping) {
                    console.log(`\n${C.RED}[INTERRUPT]${C.RESET} Architect is active! Applying emergency brakes...`);
                    break;
                }
                await new Promise(resolve => setTimeout(resolve, 100)); // 600 * 100ms = 60,000ms (1 min)                                                      
            }
        }                                                         
        
        // Morning Routine
        console.log(`\n${C.GREEN}${C.BOLD}[WAKE UP]${C.RESET} Night Train arrived! Pika is evolved and ready, Boss! 🚀`);                   
        try { trackAction("SYSTEM", "Night Train Stopped", `Successfully completed ${cycleCount} evolution cycles.`, true); } catch(e){}

    } catch (error) {
        console.log(`${C.RED}[CRASH]${C.RESET} Night Train derailed: ${error.message}`);
        try { trackAction("ERROR", "Night Train Crash", error.message); } catch(e){}                                                                
    }
}

module.exports = { startNightTrain };
