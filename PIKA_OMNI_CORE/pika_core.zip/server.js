const express = require('express');
const path = require('path');
const fs = require('fs-extra');
const os = require('os');
const { exec } = require('child_process');

// ==========================================
// 🧠 NEURAL CORE & SERVICES INTEGRATION
// ==========================================
const { processMessage, autonomousPulse, executeNeuralTask, startPikaAwakening } = require('./core/router.js');
const { trackAction } = require('./services/tracker.js');
const { startNightTrain } = require('./services/night_train.js');
const { startFeeder } = require('./services/feeder.js');
const { runInfiniteLoop } = require('./services/auto_crawler.js');
const { startAutoEvolutionLoop } = require('./services/autonomous_mutator.js');
const { evolve } = require('./core/evolution_engine.js');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ==========================================
// 🎨 TERMINAL COLORS (Clean Palette)
// ==========================================
const C = {
    BLUE: "\x1b[38;5;45m", GREEN: "\x1b[38;5;82m", YELLOW: "\x1b[38;5;226m",
    ORANGE: "\x1b[38;5;214m", RED: "\x1b[38;5;196m", WHITE: "\x1b[38;5;231m",
    PURPLE: "\x1b[38;5;213m", CYAN: "\x1b[38;5;51m", GRAY: "\x1b[38;5;240m",
    BG_BLUE: "\x1b[48;5;17m", BOLD: "\x1b[1m", RESET: "\x1b[0m"   
};

const DATA_DIR = path.join(__dirname, 'data');
const UTILS_DIR = path.join(__dirname, 'utils');
const BACKUPS_DIR = path.join(__dirname, 'backups');
const LOGS_DIR = path.join(__dirname, 'logs');
const IDENTITY_PATH = path.join(DATA_DIR, 'identity_core.json');  
const CONFIG_PATH = path.join(DATA_DIR, 'semantic_config.json');
const DATASET_VAULT = path.join(DATA_DIR, 'dataset_vault.jsonl');

// ==========================================
// 🚀 PRE-FLIGHT BOOT SEQUENCE
// ==========================================
async function preFlightCheck() {
    process.stdout.write("\x1Bc"); // Clear complete screen
    console.log(`${C.CYAN}${C.BOLD}`);
    console.log(`  ██▓███   ██▓ ██ ▄█▀ ▄▄▄       ▄▄▄       ▄████  ██▓`);
    console.log(` ▓██░  ██▒▓██▒ ██▄█▒ ▒████▄    ▒████▄    ██▒ ▀█▒▓██▒`);
    console.log(` ▓██░ ██▓▒▒██▒▓███▄░ ▒██  ▀█▄  ▒██  ▀█▄ ▒██░▄▄▄░▒██▒`);
    console.log(` ▒██▄█▓▒ ▒░██░▓██ █▄ ░██▄▄▄▄██ ░██▄▄▄▄██░▓█  ██▓░██░`);
    console.log(` ▒██▒ ░  ░░██░▒██▒ █▄ ▓█   ▓██▒ ▓█   ▓██▒░▒▓███▀▒░██░`);                                                           
    console.log(` ▒▓▒░ ░  ░░▓  ▒ ▒▒ ▓▒ ▒▒   ▓▒█░ ▒▒   ▓▒█░ ░▒   ▒ ░▓  `);
    console.log(` ░▒ ░      ▒ ░░ ░▒ ▒░  ▒   ▒▒ ░  ▒   ▒▒ ░  ░   ░  ▒ ░`);                                                           
    console.log(` ░░        ▒ ░░ ░░ ░   ░   ▒     ░   ▒   ░ ░   ░  ▒ ░`);
    console.log(`           ░  ░  ░         ░  ░      ░  ░      ░  ░  `);
    console.log(`========================================================${C.RESET}`);
    console.log(`${C.PURPLE}[SYSTEM BOOT]${C.RESET} Initializing Generative AI Neural Pathways...`);                                

    await fs.ensureDir(DATA_DIR);
    await fs.ensureDir(UTILS_DIR);
    await fs.ensureDir(BACKUPS_DIR);
    await fs.ensureDir(LOGS_DIR);

    if (!fs.existsSync(IDENTITY_PATH)) {
        console.error(`${C.RED}[FATAL ERROR]${C.RESET} identity_core.json missing! Neural core cannot boot.`);
        process.exit(1);
    }

    const idData = await fs.readJson(IDENTITY_PATH);              
    if (idData?.identity?.name !== "Pika" || idData?.identity?.architect !== "Ankit") {
        console.error(`${C.RED}[SECURITY OVERRIDE]${C.RESET} Architect signature mismatch detected!`);                              
        process.exit(1);
    }

    let cognitiveWeight = 1.0;
    let knownConcepts = 0;
    if (fs.existsSync(CONFIG_PATH)) {
        const config = await fs.readJson(CONFIG_PATH);
        cognitiveWeight = config.weights ? config.weights.default : 1.0;                                                            
        knownConcepts = Object.keys(config.tech_core || {}).length + Object.keys(config.action || {}).length;
    }

    let datasetSize = "0 KB";
    if (fs.existsSync(DATASET_VAULT)) {                           
        const stats = await fs.stat(DATASET_VAULT);
        datasetSize = (stats.size / 1024).toFixed(2) + " KB";
    }
                                                                  
    console.log(`${C.GREEN}[CORE READY]${C.RESET} Identity: Verified | Architect: ${C.YELLOW}Ankit${C.RESET} | Engine: ${C.BLUE}Sovereign AGI V12${C.RESET}`);                                                                                                          
    console.log(`${C.CYAN}[ML MIND SYNC]${C.RESET} Base Cognitive Weight: ${C.PURPLE}${cognitiveWeight} PBU${C.RESET} | Mastered Concepts: ${C.GREEN}${knownConcepts}${C.RESET}`);                                                                                      
    console.log(`${C.PURPLE}[DATA LAKE]${C.RESET} Current Pre-Training Dataset Size: ${C.YELLOW}${datasetSize}${C.RESET}\n`);
}                                                                 

// ==========================================
// 💤 IMMORTAL SLEEP CYCLE (Clean Background Execution)
// ==========================================
let sleepTimer;
global.isSleeping = false;
const INACTIVITY_LIMIT = 5 * 60 * 1000; // 5 Minutes                                                                                                                                                  

function resetSleepTimer() {
    clearTimeout(sleepTimer);

    if (global.isSleeping) {
        global.isSleeping = false;
        console.log(`\n${C.BG_BLUE}${C.WHITE}[PIKA AWAKE]${C.RESET} Architect presence detected. Background execution paused.`);                                                                       
        trackAction("AWAKE", "System", "Architect resumed interaction. Cognitive focus restored.");
    }

    sleepTimer = setTimeout(async () => {
        if (!global.isSleeping) {
            global.isSleeping = true;
            trackAction("SLEEP_MODE_ACTIVATED", "System", "Inactivity detected. Switching to Autonomous Evolution State.");
            console.log(`\n${C.PURPLE}[PIKA SLEEPING]${C.RESET} Entering REM State. Igniting Background Neural Algorithms...`);
                                                                  
            try {
                console.log(`${C.CYAN}[NIGHT SHIFT]${C.RESET} Initiating autonomous neural tasks (Deadlock Free)...`);

                // 🌟 DEADLOCK FIX: Sequential Awaits without locking the global API Gate
                await startFeeder().catch(e => {});                          
                if (typeof startNightTrain === 'function') startNightTrain();
                
                await evolve().catch(e => {});
                
                // Auto Mutator/Pulse Logic
                await autonomousPulse().catch(e => {});

            } catch (err) {                                       
                console.error(`\n${C.RED}[SLEEP CRASH]${C.RESET} Generative background loop failed: ${err.message}`);
                trackAction("CRASH", "Background Operations", err.message);
            }
        }
    }, INACTIVITY_LIMIT);
}                                                                                                                                   

// ==========================================
// 🌐 API ENDPOINTS & CHAT INTERFACE
// ==========================================
app.get('/api/vault', async (req, res) => {                       
    const fileKey = req.query.file;
    let targetPath = '';                                          

    switch(fileKey) {                                             
        case 'identity': targetPath = path.join(DATA_DIR, 'identity_core.json'); break;
        case 'memory': targetPath = path.join(DATA_DIR, 'pending_learning.json'); break;
        case 'tracker': targetPath = path.join(DATA_DIR, 'chat_history.json'); break;
        case 'config': targetPath = path.join(DATA_DIR, 'semantic_config.json'); break;                                                                                                                                                                                 
        case 'dataset': targetPath = DATASET_VAULT; break;
        default: return res.status(400).json({ error: "Access Denied: Invalid Vault Key." });
    }                                                             

    try {                                                                                                                           
        if (await fs.pathExists(targetPath)) {
            if (targetPath.endsWith('.json')) {
                const content = await fs.readJson(targetPath);
                res.json({ content });
            } else {
                const content = await fs.readFile(targetPath, 'utf-8');
                res.json({ content });                            
            }
            console.log(`${C.YELLOW}[SHADOW VAULT]${C.RESET} Authorized retrieval granted for node: ${fileKey}`);
        } else {
            res.status(404).json({ error: `Cognitive file [${fileKey}] not initialized in memory matrices yet.` });                 
        }
    } catch (err) {                                               
        res.status(500).json({ error: "Failed to decrypt vault file." });
    }                                                             
});

app.post('/api/chat', async (req, res) => {
    resetSleepTimer();                                            
    const userMsg = req.body.message;                                                                                                                                                                                                                                   
    if (!userMsg) return res.status(400).json({ reply: "Transmission empty." });

    console.log(`\n${C.ORANGE}[ARCHITECT ANKIT]${C.RESET} ${userMsg}`);

    try {
        const reply = await processMessage(userMsg, false);
                                                                  
        console.log(`\n${C.CYAN}╭─────────────────────────────────────────────────────────╮${C.RESET}`);
        console.log(`${C.CYAN}│  ${C.BOLD}PIKA NEURAL RESPONSE${C.RESET}`);
        console.log(`${C.CYAN}├─────────────────────────────────────────────────────────┤${C.RESET}`);
        const formattedReply = reply.split('\n').map(line => `${C.WHITE}${line}${C.RESET}`).join('\n');
        console.log(`${formattedReply}`);
        console.log(`${C.CYAN}╰─────────────────────────────────────────────────────────╯${C.RESET}\n`);

        res.json({ reply: reply });                               
    } catch (error) {
        trackAction("CRASH", "server.js", error.message);
        res.status(500).json({ reply: "Neural pathways glitched. Analyzing internal logs..." });
    }
});

// ==========================================
// 🛡️ IMMORTAL CRASH HANDLERS
// ==========================================
process.on('unhandledRejection', (reason, promise) => {
    console.error(`\n${C.RED}[UNHANDLED REJECTION]${C.RESET} Background process failed: ${reason}`);
    trackAction("CRITICAL_ERROR", "Global", `Unhandled Rejection: ${reason}`);
});

process.on('uncaughtException', (err) => {
    console.error(`\n${C.RED}[UNCAUGHT EXCEPTION]${C.RESET} System integrity breached: ${err.message}`);
    trackAction("CRITICAL_ERROR", "Global", `Uncaught Exception: ${err.message}`);
});

// ==========================================
// 🌐 SYSTEM IGNITION
// ==========================================
const PORT = 3000;
(async () => {
    await preFlightCheck();                                       
    const server = app.listen(PORT, async () => {
        console.log(`${C.WHITE}[NETWORK UPLINK]${C.RESET} ${C.BLUE}http://localhost:${PORT}${C.RESET}`);

        try {
            console.log(`${C.YELLOW}[BOOT PROTOCOL]${C.RESET} Digesting pending technical archives in background...`);              
            // 🌟 NON-BLOCKING BOOT: Feeder runs quietly, server starts instantly
            startFeeder().catch(e => {});
        } catch (err) {}                                          

        trackAction("SYSTEM_START", "server.js", "PIKA V12 AGI Engine Booted Successfully.");
        resetSleepTimer();                                        
        console.log(`${C.YELLOW}[SYSTEM]${C.RESET} Igniting Background Curiosity & Mutation Engines...`);

        if (typeof runInfiniteLoop === 'function') {
            runInfiniteLoop(2);
            console.log(`${C.GREEN}[CRAWLER]${C.RESET} Curiosity Engine Online (Global Queue Synced).`);
        }
        if (typeof startAutoEvolutionLoop === 'function') {
            startAutoEvolutionLoop();
            console.log(`${C.GREEN}[MUTATOR]${C.RESET} Autonomous Evolution Loop Online (Global Queue Synced).`);                   
        }
        if (typeof startPikaAwakening === 'function') {
            startPikaAwakening();
        }
    });

    process.on('SIGINT', async () => {
        console.log(`\n\n${C.RED}[SHUTDOWN INITIATED]${C.RESET} Safely archiving neural weights and conserving Data Lake...`);      
        clearTimeout(sleepTimer);
        trackAction("SYSTEM_OFFLINE", "server.js", "Manual shutdown triggered by Architect.");
                                                                  
        server.close(() => {
            console.log(`${C.PURPLE}================================================================${C.RESET}`);                                                                                     
            console.log(`${C.WHITE} Pika AGI has safely detached from the matrix. See you soon, Boss!${C.RESET} 🤖💤`);
            console.log(`${C.PURPLE}================================================================${C.RESET}`);
            process.exit(0);
        });
    });
})();
