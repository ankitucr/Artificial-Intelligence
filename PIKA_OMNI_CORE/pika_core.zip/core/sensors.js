const { exec } = require('child_process');
const os = require('os'); 
const { trackAction } = require('../services/tracker.js'); // 🌟 NERVOU SYSTEM SYNC

// 🎨 PROFESSIONAL MATRIX COLORS
const C = { 
    RED: "\x1b[31m", 
    GREEN: "\x1b[32m", 
    CYAN: "\x1b[36m", 
    YELLOW: "\x1b[33m", 
    PURPLE: "\x1b[35m", 
    BLUE: "\x1b[34m",
    RESET: "\x1b[0m",
    BOLD: "\x1b[1m"
};

/**
 * Executes a Termux API command with robust error handling, timeout, and massive buffer.
 * @param {string} command - The termux-api command to run.
 * @param {number} timeoutMs - Max time to wait in milliseconds.
 */
function senseEnvironment(command, timeoutMs = 15000) { // Increased timeout for deep sweeps
    return new Promise((resolve) => {
        exec(command, { timeout: timeoutMs, maxBuffer: 1024 * 1024 * 50 }, (error, stdout, stderr) => {
            if (error) {
                resolve({ status: 'FAILED', reason: error.message.split('\n')[0] });
                return;
            }
            try {
                resolve({ status: 'SUCCESS', data: JSON.parse(stdout) });
            } catch (parseError) {
                resolve({ status: 'SUCCESS', data: stdout.trim() });
            }
        });
    });
}

// ==========================================
// 👁️ THE GOD MODE SENSORY ENGINE
// ==========================================
async function runSensors(deepSweep = true) {
    console.log(`\n${C.PURPLE}${C.BOLD}=== [SENSORY ENGINE ACTIVATED] ===${C.RESET}`);
    console.log(`${C.CYAN}[SCANNING]${C.RESET} Initiating Full Device Access Sweep...`);

    const sensoryData = {
        timestamp: new Date().toISOString(),
        internalVitals: {},
        powerVitals: {},
        networkVitals: {},
        shortTermMemory: {},
        audioState: {},
        spatialAwareness: {},
        hardwareSenses: {},
        socialAwareness: {}
    };

    try {
        // 🧠 1. INTERNAL VITALS (OS & Brain Capacity)
        process.stdout.write(`${C.BLUE}-> [Internal] Checking Brain Core (CPU/RAM)... ${C.RESET}`);
        sensoryData.internalVitals = {
            platform: os.platform(),
            architecture: os.arch(),
            cpuCores: os.cpus().length,
            totalMemoryMB: (os.totalmem() / (1024 * 1024)).toFixed(2),
            freeMemoryMB: (os.freemem() / (1024 * 1024)).toFixed(2),
            uptimeSeconds: os.uptime()
        };
        console.log(`${C.GREEN}SUCCESS${C.RESET}`);

        // 🔋 2. POWER VITALS (Battery)
        process.stdout.write(`${C.BLUE}-> [Power] Scanning Battery Energy... ${C.RESET}`);
        sensoryData.powerVitals.battery = await senseEnvironment('termux-battery-status');
        console.log(sensoryData.powerVitals.battery.status === 'SUCCESS' ? `${C.GREEN}SUCCESS${C.RESET}` : `${C.RED}FAILED${C.RESET}`);
        
        // Smart Hardware Alert
        if (sensoryData.powerVitals.battery.status === 'SUCCESS' && sensoryData.powerVitals.battery.data.percentage < 15) {
            trackAction("SYSTEM_WARNING", "Battery", `Critical Power Level: ${sensoryData.powerVitals.battery.data.percentage}%`);
        }

        // 📋 3. SHORT TERM MEMORY (Clipboard)
        process.stdout.write(`${C.BLUE}-> [Memory] Reading Clipboard Buffer... ${C.RESET}`);
        sensoryData.shortTermMemory.clipboard = await senseEnvironment('termux-clipboard-get');
        console.log(sensoryData.shortTermMemory.clipboard.status === 'SUCCESS' ? `${C.GREEN}SUCCESS${C.RESET}` : `${C.RED}FAILED${C.RESET}`);

        // 🔊 4. AUDIO STATE (Volume)
        process.stdout.write(`${C.BLUE}-> [Audio] Scanning Volume Levels... ${C.RESET}`);
        sensoryData.audioState.volume = await senseEnvironment('termux-volume');
        console.log(sensoryData.audioState.volume.status === 'SUCCESS' ? `${C.GREEN}SUCCESS${C.RESET}` : `${C.RED}FAILED${C.RESET}`);

        // 📶 5. NETWORK VITALS (WiFi & Cellular)
        process.stdout.write(`${C.BLUE}-> [Network] Scanning Connection Vitals... ${C.RESET}`);
        sensoryData.networkVitals.wifi = await senseEnvironment('termux-wifi-connectioninfo');
        sensoryData.networkVitals.cellular = await senseEnvironment('termux-telephony-deviceinfo');
        console.log(`${C.GREEN}SUCCESS${C.RESET}`);

        // ==========================================
        // 🚀 THE DEEP SWEEP (Heavy Read/Write Access)
        // ==========================================
        if (deepSweep) {
            console.log(`${C.YELLOW}[DEEP SWEEP]${C.RESET} Extracting advanced hardware and social telemetry...`);

            // 🌍 6. SPATIAL AWARENESS (Location)
            process.stdout.write(`${C.BLUE}-> [Spatial] Locking Global GPS Coordinates... ${C.RESET}`);
            sensoryData.spatialAwareness.location = await senseEnvironment('termux-location', 15000);
            console.log(sensoryData.spatialAwareness.location.status === 'SUCCESS' ? `${C.GREEN}SUCCESS${C.RESET}` : `${C.YELLOW}TIMEOUT/FAILED${C.RESET}`);

            // 📱 7. SOCIAL AWARENESS (Logs & Contacts)
            process.stdout.write(`${C.BLUE}-> [Social] Scraping SMS, Calls, and Contacts... ${C.RESET}`);
            sensoryData.socialAwareness.recentSms = await senseEnvironment('termux-sms-list -l 10');
            sensoryData.socialAwareness.recentCalls = await senseEnvironment('termux-call-log -l 10');
            sensoryData.socialAwareness.contacts = await senseEnvironment('termux-contact-list');
            console.log(`${C.GREEN}SUCCESS${C.RESET}`);

            // 📷 8. HARDWARE SENSES (Camera & Physical Sensors)
            process.stdout.write(`${C.BLUE}-> [Hardware] Indexing Camera Eyes & Gyro Sensors... ${C.RESET}`);
            sensoryData.hardwareSenses.cameras = await senseEnvironment('termux-camera-info');
            sensoryData.hardwareSenses.liveSensors = await senseEnvironment('termux-sensor -a -n 1');
            console.log(`${C.GREEN}SUCCESS${C.RESET}`);
        }

        console.log(`\n${C.GREEN}${C.BOLD}[SENSORS COMPLETE]${C.RESET} Pika has successfully assimilated physical device state.`);
        
        // Log the successful sweep to Pika's Vault/Tracker
        trackAction("SYSTEM_SENSORS", "Hardware Sweep", `Deep Sweep: ${deepSweep}. Extracted full device telemetry.`, true);

        return sensoryData;

    } catch (error) {
        console.log(`\n${C.RED}[SENSOR CRASH]${C.RESET} Neural link to hardware failed: ${error.message}`);
        trackAction("ERROR", "sensors.js", error.message);
        return sensoryData; // Return whatever was gathered before crash
    }
}

// Export for Pika's Memory Manager or Router
module.exports = { runSensors };
