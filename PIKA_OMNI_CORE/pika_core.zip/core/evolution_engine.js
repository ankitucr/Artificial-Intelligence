const fs = require('fs-extra');
const path = require('path');
const nlp = require('compromise');
const crypto = require('crypto');
const { trackAction } = require('../services/tracker.js');
const { generateTool } = require('../services/logic_factory.js');
require('dotenv').config();

// 📂 DYNAMIC DIRECTORY PATHS
const DATA_DIR = path.join(__dirname, '../data');
const BACKUP_DIR = path.join(__dirname, '../backups');
const PENDING_FILE = path.join(DATA_DIR, 'pending_learning.json');
const CONFIG_FILE = path.join(DATA_DIR, 'semantic_config.json');
const IDENTITY_FILE = path.join(DATA_DIR, 'identity_core.json');
const DATASET_VAULT = path.join(DATA_DIR, 'dataset_vault.jsonl'); // 🌟 The Deep Archive
const STATE_FILE = path.join(DATA_DIR, 'evolution_state.json');
const CORE_DIR = __dirname;
const TOOLS_DIR = path.join(__dirname, '../utils/tools');

// 🎨 TERMINAL MATRICES
const C = {
    RED: "\x1b[31m", GREEN: "\x1b[32m", CYAN: "\x1b[36m",
    PURPLE: "\x1b[35m", YELLOW: "\x1b[33m", BLUE: "\x1b[34m",
    RESET: "\x1b[0m", BOLD: "\x1b[1m"
};

const delay = (ms) => new Promise(res => setTimeout(res, ms));

// 📋 CORE FILES TO UPGRADE (Target architecture files)
const CORE_FILES = [
    'pika_core.js',
    'router.js',
    'learning_algorithm.js',
    'memory_manager.js',
    'sensors.js'
];

// ==========================================
// PART 1: COGNITIVE EVOLUTION (Semantic Engine)
// ==========================================

// 🛡️ MEMORY BACKUP & HASHING ENGINE
async function createBrainBackup(config) {
    try {
        await fs.ensureDir(BACKUP_DIR);
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const hash = crypto.createHash('md5').update(JSON.stringify(config)).digest('hex').substring(0, 8);
        const backupPath = path.join(BACKUP_DIR, `brain_backup_${timestamp}_${hash}.json`);
        await fs.writeJson(backupPath, config, { spaces: 2 });
        return hash;
    } catch (error) {
        console.error(`${C.RED}[BACKUP FAILED]${C.RESET} Unable to secure cognitive state.`, error.message);
        throw error;
    }
}

// 🌌 THE DEEP ARCHIVER (Offline AGI Dream)
async function archiveToVault(staleConcepts) {
    try {
        if (staleConcepts.length === 0) return;
        let archiveData = "";
        const timestamp = new Date().toISOString();
        staleConcepts.forEach(concept => {
            archiveData += JSON.stringify({ timestamp, type: "ARCHIVED_COGNITION", concept }) + '\n';
        });
        await fs.appendFile(DATASET_VAULT, archiveData, 'utf8');
        console.log(`${C.PURPLE}[DEEP ARCHIVE]${C.RESET} ${staleConcepts.length} concepts permanently vaulted for offline LLM training.`);
    } catch (e) {
        console.error(`${C.RED}[ARCHIVE ERROR]${C.RESET} Failed to vault old memories.`);
    }
}

// 🧠 THE CORE SEMANTIC ENGINE (Self-Aware)
async function evolve() {
    console.log(`\n${C.PURPLE}${C.BOLD}=== [SEMANTIC EVOLUTION ONLINE] ===${C.RESET}`);
    console.log(`${C.CYAN}[SYSTEM]${C.RESET} Initiating Deep Semantic Injection Protocol...`);
    try {
        // 🛡️ 1. IDENTITY GUARD
        const identityData = await fs.readJson(IDENTITY_FILE).catch(() => null);
        const isValidConsciousness = identityData?.identity?.name === "Pika" &&
            identityData?.identity?.architect?.toLowerCase() === "ankit";
        if (!isValidConsciousness) {
            console.error(`${C.RED}[FATAL ALIENATION]${C.RESET} Unauthorized consciousness detected. Shutting down.`);
            trackAction("SECURITY_ALERT", "identity_core.json", "Evolution halted. Identity mismatch.");
            return;
        }

        // 🧠 2. LOAD COGNITIVE STATE
        let rawPending = await fs.readJson(PENDING_FILE).catch(() => []);
        let config = await fs.readJson(CONFIG_FILE).catch(() => ({
            tech_core: {}, action: {}, weights: { default: 1.0, learning_rate: 0.05 }, synapses: 0
        }));
        
        if (!Array.isArray(rawPending) || rawPending.length === 0) {
            console.log(`${C.GREEN}[IDLE]${C.RESET} Neural pathways optimized. No pending semantic concepts.`);
            return;
        }

        // ⚡ Array Deduplication
        let pending = [...new Set(rawPending)];
        console.log(`${C.YELLOW}[DATA STREAM]${C.RESET} Processing ${pending.length} unique raw neural packets...`);

        // 💾 3. CRITICAL BACKUP
        const hash = await createBrainBackup(config);
        console.log(`${C.BLUE}[BACKUP]${C.RESET} Cognitive state hashed: ${hash}`);

        // 🧬 4. DEEP LOGIC INJECTION & HINGLISH SYNERGY
        let injectedCount = 0;
        let freshPending = [];
        let newlyLearned = [];
        let coreMastery = [];

        pending.forEach(phrase => {
            if (typeof phrase !== 'string') return;
            let cleanPhrase = phrase.toLowerCase().trim();
            let doc = nlp(cleanPhrase);

            // Hinglish & Advanced Tagging Support
            doc.match('(javascript|python|api|server|database|json|termux|agi|ai|llm)').tag('#Technology');
            doc.match('(karo|banao|likho|dhundo|search|fix|solve|update)').tag('#Action');

            let isTech = doc.match('#Technology').found || doc.match('#Software').found || doc.nouns().found;
            let isAction = doc.match('#Action').found || doc.verbs().found;
            let word = doc.text();

            if (word.length < 3) return;

            if (isTech) {
                if (!config.tech_core[word]) {
                    config.tech_core[word] = { confidence: 0.1, first_seen: Date.now() };
                    injectedCount++; newlyLearned.push(word);
                } else {
                    config.tech_core[word].confidence = Math.min(1.0, config.tech_core[word].confidence + config.weights.learning_rate);
                    if (config.tech_core[word].confidence === 1.0 && !coreMastery.includes(word)) coreMastery.push(word);
                }
                freshPending.push(word);
            }
            else if (isAction) {
                if (!config.action[word]) {
                    config.action[word] = { confidence: 0.1, first_seen: Date.now() };
                    injectedCount++;
                } else {
                    config.action[word].confidence = Math.min(1.0, config.action[word].confidence + config.weights.learning_rate);
                    if (config.action[word].confidence === 1.0 && !coreMastery.includes(word)) coreMastery.push(word);
                }
                freshPending.push(word);
            }
        });

        // ⚙️ 5. NEURAL WEIGHT OPTIMIZATION
        const totalTech = Object.keys(config.tech_core).length;
        const totalAction = Object.keys(config.action).length;
        config.synapses = totalTech + totalAction;

        if (config.synapses > 10) {
            config.weights.default = parseFloat((1.0 + Math.log10(1 + (config.synapses / 100))).toFixed(3));
        }

        // 🗑️ 6. THE ARCHIVER
        if (freshPending.length > 500) {
            const staleConcepts = freshPending.slice(0, freshPending.length - 500);
            freshPending = freshPending.slice(-500);
            await archiveToVault(staleConcepts);
        }

        // 🚀 7. PERMANENT SYSTEM REWRITE
        await fs.writeJson(CONFIG_FILE, config, { spaces: 2 });
        await fs.writeJson(PENDING_FILE, freshPending, { spaces: 2 });
        trackAction("COGNITIVE_EVOLUTION", "semantic_config.json", `Synapses: ${injectedCount} | Vaulted: ${pending.length - freshPending.length}`);

        // 🎉 ARCHITECTURAL SUMMARY LOGS
        console.log(`\n${C.GREEN}${C.BOLD}=== [SEMANTIC SEQUENCE SUCCESSFUL] ===${C.RESET}`);
        console.log(`✔️ New Synapses Injected  : ${C.CYAN}${injectedCount}${C.RESET}`);
        if (newlyLearned.length > 0) console.log(`🌱 New Concepts Found    : ${C.YELLOW}${newlyLearned.slice(0, 4).join(', ')}${newlyLearned.length > 4 ? '...' : ''}${C.RESET}`);
        if (coreMastery.length > 0) console.log(`🔥 Core Mastery (100%)   : ${C.PURPLE}${C.BOLD}${coreMastery.slice(0, 3).join(', ')}${C.RESET}`);
        console.log(`⚖️ Current Brain Weight   : ${C.PURPLE}${config.weights.default}${C.RESET} PBU\n`);
    } catch (error) {
        console.error(`${C.RED}[EVOLUTION FAILURE]${C.RESET} Critical anomaly during neuro-plasticity:`, error.message);
        trackAction("CRASH", "evolution_engine.js", error.message);
    }
}

// ==========================================
// PART 2: STRUCTURAL EVOLUTION (The Builder)
// ==========================================

// 🧠 STATE TRACKER
async function loadState() {
    await fs.ensureDir(DATA_DIR);
    if (fs.existsSync(STATE_FILE)) return await fs.readJson(STATE_FILE);
    // Default State Initialization
    return {
        phase: "UPGRADE_CORE",     // UPGRADE_CORE or GENESIS_MODE
        fileIndex: 0,              // Current file being processed
        functionsAdded: 0,         // Functions injected in current file (Target: 3)
        genesisFilesBuilt: 0,      // Total new architectures created
        currentGenesisFile: null,  // Name of the active genesis file
        genesisFunctionsAdded: 0   // Functions injected into genesis file (Target: 20)
    };
}

async function saveState(state) {
    await fs.writeJson(STATE_FILE, state, { spaces: 2 });
}

// 🧬 THE ARCHITECTURE LOOP (Mastermind Builder)
async function runEvolutionCycle() {
    console.log(`\n${C.PURPLE}${C.BOLD}=== [STRUCTURAL EVOLUTION AWAKENED] ===${C.RESET}`);
    let state = await loadState();

    // ---------------------------------------------------------
    // 🛠️ PHASE 1: CORE FILES UPGRADE (3-Function Rule)
    // ---------------------------------------------------------
    if (state.phase === "UPGRADE_CORE") {
        if (state.fileIndex >= CORE_FILES.length) {
            console.log(`${C.GREEN}[MILESTONE]${C.RESET} All Core files upgraded! Shifting to GENESIS MODE...`);
            state.phase = "GENESIS_MODE";
            await saveState(state);
            return await runEvolutionCycle(); // Recursive call for mode shift
        }

        let currentFile = CORE_FILES[state.fileIndex];
        let targetPath = path.join(CORE_DIR, currentFile);

        console.log(`${C.CYAN}[TARGET LOCKED]${C.RESET} Upgrading ${currentFile} | Functions added: ${state.functionsAdded}/3`);

        if (state.functionsAdded < 3) {
            let actionName = `auto_upgrade_${currentFile.replace('.js', '')}_fn${state.functionsAdded + 1}`;
            let description = `Add a highly advanced, intelligent utility function to improve the capabilities of ${currentFile}. Ensure it handles edge cases and errors gracefully.`;

            let success = await generateTool(actionName, description, targetPath);

            if (success) {
                state.functionsAdded++;
                await saveState(state);
                console.log(`${C.GREEN}[STABILIZATION]${C.RESET} Function integrated successfully.`);
                
                // 🔥 THE HUMAN GAP: 20-second break to avoid API IP bans
                console.log(`${C.YELLOW}[API PACING]${C.RESET} Resting for 20 seconds to avoid IP bans...`);
                await delay(20000); 
            } else {
                console.log(`${C.RED}[MUTATION FAILED]${C.RESET} AI failed or Sandboxed. Will retry in next cycle.`);
                await delay(10000); 
            }
        } 
        
        // Stabilize and move to next file
        if (state.functionsAdded >= 3) {
            console.log(`${C.PURPLE}[FILE STABILIZED]${C.RESET} ${currentFile} is now hyper-evolved! Moving to next file.`);
            state.functionsAdded = 0;
            state.fileIndex++;
            await saveState(state);
            await delay(5000);
        }
    }

    // ---------------------------------------------------------
    // 🌌 PHASE 2: GENESIS MODE (Creating Brand New Architecture)
    // ---------------------------------------------------------
    else if (state.phase === "GENESIS_MODE") {
        console.log(`${C.CYAN}[GENESIS MODE]${C.RESET} Forging brand new neural pathways...`);

        if (!state.currentGenesisFile) {
            state.currentGenesisFile = `quantum_module_${state.genesisFilesBuilt + 1}`;
            state.genesisFunctionsAdded = 0;
            await saveState(state);
        }

        let targetPath = path.join(TOOLS_DIR, `${state.currentGenesisFile}.js`);
        console.log(`${C.YELLOW}[BUILDING NEW ARCHITECTURE]${C.RESET} File: ${state.currentGenesisFile}.js | Functions: ${state.genesisFunctionsAdded}/20`);

        if (state.genesisFunctionsAdded < 20) {
            let actionName = `${state.currentGenesisFile}_fn${state.genesisFunctionsAdded + 1}`;
            let description = `Write an advanced modular function for a new AGI subsystem called ${state.currentGenesisFile}. Feature ${state.genesisFunctionsAdded + 1} of 20.`;

            let isFirstFunction = (state.genesisFunctionsAdded === 0);
            let success = await generateTool(actionName, description, isFirstFunction ? null : targetPath);

            if (success) {
                state.genesisFunctionsAdded++;
                await saveState(state);
                console.log(`${C.GREEN}[GENESIS SUCCESS]${C.RESET} New function embedded.`);
                
                // 🔥 THE HUMAN GAP
                console.log(`${C.YELLOW}[API PACING]${C.RESET} Resting for 20 seconds...`);
                await delay(20000);
            } else {
                console.log(`${C.RED}[GENESIS FAILED]${C.RESET} Retrying in next pulse...`);
                await delay(10000);
            }
        }

        // Module completion
        if (state.genesisFunctionsAdded >= 20) {
            console.log(`${C.PURPLE}[NEW MODULE COMPLETE]${C.RESET} ${state.currentGenesisFile}.js is fully operational!`);
            state.currentGenesisFile = null;
            state.genesisFunctionsAdded = 0;
            state.genesisFilesBuilt++;
            await saveState(state);
            
            // Continuous Evolution Loop - Return to Core Upgrade
            if(state.genesisFilesBuilt >= 1) { 
                 console.log(`${C.CYAN}[LOOP RESTART]${C.RESET} Going back to upgrade Core Files...`);
                 state.phase = "UPGRADE_CORE";
                 state.fileIndex = 0;
                 await saveState(state);
            }
        }
    }
}

// ==========================================
// 🚀 MANUAL EXECUTION TRIGGER
// ==========================================
if (require.main === module) {
    (async () => {
        await evolve(); // Runs semantic learning first
        await runEvolutionCycle(); // Then runs architecture building
    })();
}

module.exports = { evolve, runEvolutionCycle };
