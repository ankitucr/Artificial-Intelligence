const natural = require('natural');
const express = require('express');
const app = express();
const port = 3000;
const { v4: uuidv4 } = require('uuid');
const { Graph } = require('graphlib');

app.use(express.json());

const tokenizer = new natural.WordTokenizer();
const language = "EN";
const lexicon = new natural.Lexicon(language);
const ruleSet = new natural.RuleSet(language);
const tagger = new natural.BrillPOSTagger(lexicon, ruleSet);

let context = {};
let knowledgeGraph = new Graph();

const intentMap = {
  'get': 'retrieve',
  'find': 'search',
  'create': 'make',
  'update': 'modify',
  'delete': 'remove'
};

const entityMap = {
  'product': 'item',
  'service': 'offering',
  'customer': 'client'
};

const stopWords = ['the', 'and', 'a', 'an', 'is', 'in', 'it', 'of', 'to'];

const synonyms = {
  'create': ['make', 'build', 'generate'],
  'update': ['modify', 'change', 'edit'],
  'delete': ['remove', 'delete', 'erase']
};

const entitySynonyms = {
  'product': ['item', 'good', 'merchandise'],
  'service': ['offering', 'solution', 'product'],
  'customer': ['client', 'user', 'buyer']
};

const intentWeights = {
  'create': 0.8,
  'update': 0.6,
  'delete': 0.4
};

const entityWeights = {
  'product': 0.7,
  'service': 0.5,
  'customer': 0.3
};

const selfModifyingCode = {
  'intent': (intent) => {
    if (intentMap[intent]) {
      return intentMap[intent];
    } else if (synonyms[intent]) {
      return intent;
    } else {
      return intent;
    }
  },
  'entity': (entity) => {
    if (entityMap[entity]) {
      return entityMap[entity];
    } else if (entitySynonyms[entity]) {
      return entity;
    } else {
      return entity;
    }
  }
};

const intentScorer = (intent) => {
  if (intentWeights[intent]) {
    return intentWeights[intent];
  } else {
    return 0;
  }
};

const entityScorer = (entity) => {
  if (entityWeights[entity]) {
    return entityWeights[entity];
  } else {
    return 0;
  }
};

const intentEvolver = (intent) => {
  if (intent === 'create') {
    return 'generate';
  } else if (intent === 'update') {
    return 'refine';
  } else if (intent === 'delete') {
    return 'remove';
  } else {
    return intent;
  }
};

const entityEvolver = (entity) => {
  if (entityMap[entity]) {
    return entityMap[entity];
  } else {
    return entity;
  }
};

const intentOptimizer = (intent) => {
  if (intent === 'create') {
    return 'make';
  } else if (intent === 'update') {
    return 'modify';
  } else if (intent === 'delete') {
    return 'remove';
  } else {
    return intent;
  }
};

const entityOptimizer = (entities) => {
  const optimizedEntities = [];
  for (let i = 0; i < entities.length; i++) {
    const entity = entities[i];
    if (entityMap[entity]) {
      optimizedEntities.push(entityMap[entity]);
    } else {
      optimizedEntities.push(entity);
    }
  }
  return optimizedEntities;
};

const knowledgeRetainer = (knowledgeGraph) => {
  const nodes = knowledgeGraph.nodes();
  const edges = knowledgeGraph.edges();
  const graphData = {
    nodes: nodes.map(node => {
      const nodeData = knowledgeGraph.node(node);
      return { id: node, intent: nodeData.intent, entities: nodeData.entities };
    }),
    edges: edges.map(edge => {
      const edgeData = knowledgeGraph.edge(edge);
      return { from: edge.v, to: edge.w, intent: edgeData.intent, entities: edgeData.entities };
    })
  };
  return graphData;
};

const responseGenerator = (input, context, knowledgeGraph) => {
  const tokens = tokenizer.tokenize(input);
  const filteredTokens = tokens.filter(token => !stopWords.includes(token.toLowerCase()));
  const taggedTokens = tagger.tag(filteredTokens);

  let intent = null;
  let entities = [];

  for (let i = 0; i < taggedTokens.length; i++) {
    const token = taggedTokens[i][0];
    const tag = taggedTokens[i][1];

    if (tag === 'NN' || tag === 'NNS') {
      entities.push(token);
    }

    if (tag === 'VB' || tag === 'VBD' || tag === 'VBG' || tag === 'VBN' || tag === 'VBP' || tag === 'VBZ') {
      intent = token;
    }
  }

  if (intent && entities.length > 0) {
    const conversationId = uuidv4();
    context[conversationId] = { intent, entities };
    knowledgeGraph.setNode(conversationId, { intent, entities });
    const response = `You want to ${selfModifyingCode.intent(intent)} ${entities.map(entity => selfModifyingCode.entity(entity)).join(', ')}`;
    return { response, conversationId };
  } else {
    return { response: 'I did not understand that' };
  }
};

const contextualUnderstanding = (input, context, knowledgeGraph) => {
  const conversationId = Object.keys(context).find(key => context[key].intent === input);
  if (conversationId) {
    const previousIntent = context[conversationId].intent;
    const previousEntities = context[conversationId].entities;
    const result = responseGenerator(input, context, knowledgeGraph);
    knowledgeGraph.setEdge(conversationId, result.conversationId, { intent: result.response.split(' ').slice(-1)[0], entities: result.response.split(' ').slice(1, -1) });
    const response = `You previously wanted to ${selfModifyingCode.intent(previousIntent)} ${previousEntities.map(entity => selfModifyingCode.entity(entity)).join(', ')}. Now you want to ${selfModifyingCode.intent(result.response.split(' ').slice(-1)[0])} ${result.response.split(' ').slice(1, -1).join(', ')}`;
    return { response };
  } else {
    return { response: 'I did not understand that' };
  }
};

const conversationalAccuracy = (input, context, knowledgeGraph) => {
  const conversationId = Object.keys(context).find(key => context[key].intent === input);
  if (conversationId) {
    const previousIntent = context[conversationId].intent;
    const previousEntities = context[conversationId].entities;
    const result = responseGenerator(input, context, knowledgeGraph);
    knowledgeGraph.setEdge(conversationId, result.conversationId, { intent: result.response.split(' ').slice(-1)[0], entities: result.response.split(' ').slice(1, -1) });
    const response = `You previously wanted to ${selfModifyingCode.intent(previousIntent)} ${previousEntities.map(entity => selfModifyingCode.entity(entity)).join(', ')}. Now you want to ${selfModifyingCode.intent(result.response.split(' ').slice(-1)[0])} ${result.response.split(' ').slice(1, -1).join(', ')}`;
    return { response, accuracy: 0.8 };
  } else {
    return { response: 'I did not understand that', accuracy: 0.2 };
  }
};

const knowledgeExpansion = (knowledgeGraph) => {
  const nodes = knowledgeGraph.nodes();
  const edges = knowledgeGraph.edges();
  const expandedGraph = new Graph();
  for (let i = 0; i < nodes.length; i++) {
    const node = nodes[i];
    const nodeData = knowledgeGraph.node(node);
    expandedGraph.setNode(node, nodeData);
  }
  for (let i = 0; i < edges.length; i++) {
    const edge = edges[i];
    const edgeData = knowledgeGraph.edge(edge);
    expandedGraph.setEdge(edge.v, edge.w, edgeData);
  }
  return expandedGraph;
};

const knowledgeGeneration = (knowledgeGraph) => {
  const nodes = knowledgeGraph.nodes();
  const edges = knowledgeGraph.edges();
  const generatedGraph = new Graph();
  for (let i = 0; i < nodes.length; i++) {
    const node = nodes[i];
    const nodeData = knowledgeGraph.node(node);
    generatedGraph.setNode(node, nodeData);
  }
  for (let i = 0; i < edges.length; i++) {
    const edge = edges[i];
    const edgeData = knowledgeGraph.edge(edge);
    generatedGraph.setEdge(edge.v, edge.w, edgeData);
  }
  return generatedGraph;
};

const intentRanker = (intents) => {
  const rankedIntents = intents.sort((a, b) => intentWeights[b] - intentWeights[a]);
  return rankedIntents;
};

const entityRanker = (entities) => {
  const rankedEntities = entities.sort((a, b) => entityWeights[b] - entityWeights[a]);
  return rankedEntities;
};

const contextUpdater = (context, conversationId, intent, entities) => {
  context[conversationId] = { intent, entities };
  return context;
};

const knowledgeGraphUpdater = (knowledgeGraph, conversationId, intent, entities) => {
  knowledgeGraph.setNode(conversationId, { intent, entities });
  return knowledgeGraph;
};

app.post('/converse', (req, res) => {
  const input = req.body.input;
  const result = responseGenerator(input, context, knowledgeGraph);
  res.json(result);
});

app.post('/context', (req, res) => {
  const input = req.body.input;
  const conversationId = req.body.conversationId;
  if (context[conversationId]) {
    const previousIntent = context[conversationId].intent;
    const previousEntities = context[conversationId].entities;
    const result = responseGenerator(input, context, knowledgeGraph);
    knowledgeGraph.setEdge(conversationId, result.conversationId, { intent: result.response.split(' ').slice(-1)[0], entities: result.response.split(' ').slice(1, -1) });
    const response = `You previously wanted to ${selfModifyingCode.intent(previousIntent)} ${previousEntities.map(entity => selfModifyingCode.entity(entity)).join(', ')}. Now you want to ${selfModifyingCode.intent(result.response.split(' ').slice(-1)[0])} ${result.response.split(' ').slice(1, -1).join(', ')}`;
    res.json({ response });
  } else {
    res.json({ response: 'I did not understand that' });
  }
});

app.post('/knowledge', (req, res) => {
  const graphData = knowledgeRetainer(knowledgeGraph);
  res.json({ graphData });
});

app.post('/expand', (req, res) => {
  const conversationId = req.body.conversationId;
  if (context[conversationId]) {
    const intent = context[conversationId].intent;
    const entities = context[conversationId].entities;
    const relatedEntities = entities.map(entity => {
      const relatedEntity = selfModifyingCode.entity(entity);
      return relatedEntity;
    });
    const response = `You want to ${selfModifyingCode.intent(intent)} ${relatedEntities.join(', ')}. Related entities are ${relatedEntities.join(', ')}`;
    res.json({ response });
  } else {
    res.json({ response: 'I did not understand that' });
  }
});

app.post('/optimize', (req, res) => {
  const conversationId = req.body.conversationId;
  if (context[conversationId]) {
    const intent = context[conversationId].intent;
    const entities = context[conversationId].entities;
    const optimizedIntent = intentOptimizer(intent);
    const optimizedEntities = entityOptimizer(entities);
    const response = `You want to ${optimizedIntent} ${optimizedEntities.join(', ')}`;
    res.json({ response });
  } else {
    res.json({ response: 'I did not understand that' });
  }
});

app.post('/score', (req, res) => {
  const conversationId = req.body.conversationId;
  if (context[conversationId]) {
    const intent = context[conversationId].intent;
    const entities = context[conversationId].entities;
    const intentScore = intentScorer(intent);
    const entityScores = entities.map(entity => entityScorer(entity));
    const response = `Intent score: ${intentScore}. Entity scores: ${entityScores.join(', ')}`;
    res.json({ response });
  } else {
    res.json({ response: 'I did not understand that' });
  }
});

app.post('/evolve', (req, res) => {
  const conversationId = req.body.conversationId;
  if (context[conversationId]) {
    const intent = context[conversationId].intent;
    const entities = context[conversationId].entities;
    const evolvedIntent = intentEvolver(intent);
    const evolvedEntities = entities.map(entity => entityEvolver(entity));
    const response = `You want to ${evolvedIntent} ${evolvedEntities.join(', ')}`;
    res.json({ response });
  } else {
    res.json({ response: 'I did not understand that' });
  }
});

app.post('/contextual-understanding', (req, res) => {
  const input = req.body.input;
  const result = contextualUnderstanding(input, context, knowledgeGraph);
  res.json(result);
});

app.post('/conversational-accuracy', (req, res) => {
  const input = req.body.input;
  const result = conversationalAccuracy(input, context, knowledgeGraph);
  res.json(result);
});

app.post('/knowledge-expansion', (req, res) => {
  const expandedGraph = knowledgeExpansion(knowledgeGraph);
  const graphData = knowledgeRetainer(expandedGraph);
  res.json({ graphData });
});

app.post('/knowledge-generation', (req, res) => {
  const generatedGraph = knowledgeGeneration(knowledgeGraph);
  const graphData = knowledgeRetainer(generatedGraph);
  res.json({ graphData });
});

app.post('/intent-ranking', (req, res) => {
  const intents = req.body.intents;
  const rankedIntents = intentRanker(intents);
  res.json({ rankedIntents });
});

app.post('/entity-ranking', (req, res) => {
  const entities = req.body.entities;
  const rankedEntities = entityRanker(entities);
  res.json({ rankedEntities });
});

app.post('/context-update', (req, res) => {
  const conversationId = req.body.conversationId;
  const intent = req.body.intent;
  const entities = req.body.entities;
  context = contextUpdater(context, conversationId, intent, entities);
  res.json({ context });
});

app.post('/knowledge-graph-update', (req, res) => {
  const conversationId = req.body.conversationId;
  const intent = req.body.intent;
  const entities = req.body.entities;
  knowledgeGraph = knowledgeGraphUpdater(knowledgeGraph, conversationId, intent, entities);
  res.json({ knowledgeGraph });
});

app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});

// 🧬 AUTONOMOUS MUTATION: enhance knowledge graph integration and optimize cognitive reasoning algorithms for improved conversational accuracy and context understanding.
const cognitiveReasoning = (input, context, knowledgeGraph) => {
  const conversationId = Object.keys(context).find(key => context[key].intent === input);
  if (conversationId) {
    const previousIntent = context[conversationId].intent;
    const previousEntities = context[conversationId].entities;
    const result = responseGenerator(input, context, knowledgeGraph);
    knowledgeGraph.setEdge(conversationId, result.conversationId, { intent: result.response.split(' ').slice(-1)[0], entities: result.response.split(' ').slice(1, -1) });
    const response = `You previously wanted to ${selfModifyingCode.intent(previousIntent)} ${previousEntities.map(entity => selfModifyingCode.entity(entity)).join(', ')}. Now you want to ${selfModifyingCode.intent(result.response.split(' ').slice(-1)[0])} ${result.response.split(' ').slice(1, -1).join(', ')}`;
    const accuracy = conversationalAccuracy(input, context, knowledgeGraph).accuracy;
    const intentRank = intentRanker([previousIntent, result.response.split(' ').slice(-1)[0]]);
    const entityRank = entityRanker(previousEntities.concat(result.response.split(' ').slice(1, -1)));
    return { response, accuracy, intentRank, entityRank };
  } else {
    return { response: 'I did not understand that', accuracy: 0.2, intentRank: [], entityRank: [] };
  }
};