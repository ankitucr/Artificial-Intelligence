const nlp = require('compromise');
const fs = require('fs-extra');
const path = require('path');
const { trackAction } = require('../services/tracker.js'); 

const CONFIG_PATH = path.join(__dirname, '../data/semantic_config.json');

const C = { 
    RED: "\x1b[31m", 
    GREEN: "\x1b[32m", 
    CYAN: "\x1b[36m", 
    PURPLE: "\x1b[35m", 
    YELLOW: "\x1b[33m", 
    BLUE: "\x1b[34m",
    RESET: "\x1b[0m",
    BOLD: "\x1b[1m"
};

// ==========================================
// 🧠 1. NON-BLOCKING COGNITIVE LOAD
// ==========================================
let cachedConfig = null;

async function loadSemanticConfig() {
    if (cachedConfig) return cachedConfig; // ⚡ Speed Boost: Read from RAM

    try {
        if (await fs.pathExists(CONFIG_PATH)) {
            cachedConfig = await fs.readJson(CONFIG_PATH);
            return cachedConfig;
        }
    } catch (error) {
        console.error(`${C.RED}[PARSER ERROR]${C.RESET} Config load failed. Generating baseline synapse.`, error.message);
    }

    // Unscripted Dynamic Baseline
    cachedConfig = {
        tech_core: {
            'python': { confidence: 0.9 }, 'javascript': { confidence: 0.9 },
            'api': { confidence: 0.8 }, 'server': { confidence: 0.8 },
            'bug': { confidence: 0.7 }, 'database': { confidence: 0.8 }
        },
        action: {
            'create': { confidence: 0.8 }, 'fix': { confidence: 0.9 },
            'evolve': { confidence: 1.0 }, 'mutate': { confidence: 1.0 },
            'search': { confidence: 0.9 }, 'hardware': { confidence: 0.8 }
        },
        weights: { default: 1.0, learning_rate: 0.05 }
    };
    return cachedConfig;
}

// ==========================================
// ⚙️ 2. DYNAMIC SYNAPTIC WEIGHTS
// ==========================================
function getWordWeight(word, config) {
    if (!word) return 0;
    let w = word.toLowerCase();
    let baseWeight = config.weights.default || 1.0;

    if (config.tech_core?.[w]) return baseWeight + 2.0 + (config.tech_core[w].confidence || 0);
    if (config.action?.[w]) return baseWeight + 1.0 + (config.action[w].confidence || 0);

    return baseWeight;
}

// ==========================================
// 🎯 3. TRUE NEURAL ATTENTION (Sigmoid)
// ==========================================
function sigmoidNormalize(x) {
    return Number((1 / (1 + Math.exp(-x + 2))).toFixed(3)); 
}

function calculateAttentionScores(tokens, config) {
    let scoredTokens = [];
    
    // Safely parse tags for different compromise versions
    const checkTag = (posTag, tag) => {
        if (!posTag) return false;
        if (Array.isArray(posTag)) return posTag.includes(tag);
        if (typeof posTag === 'object') return !!posTag[tag] || Object.keys(posTag).includes(tag) || (posTag instanceof Set && posTag.has(tag));
        return false;
    };

    for (let i = 0; i < tokens.length; i++) {
        let currentWord = tokens[i].normal || tokens[i].text.toLowerCase();
        let baseWeight = getWordWeight(currentWord, config);
        let posTag = tokens[i].tags || [];

        // Contextual Bias
        if (checkTag(posTag, 'Noun')) baseWeight += 0.5;
        if (checkTag(posTag, 'Verb')) baseWeight += 0.2;
        if (checkTag(posTag, 'Technology') || checkTag(posTag, 'Software')) baseWeight += 1.5;

        // Bidirectional Synapses (Left & Right Context)
        let leftN = (i > 0) ? getWordWeight(tokens[i-1].normal || tokens[i-1].text, config) : 0;
        let rightN = (i < tokens.length - 1) ? getWordWeight(tokens[i+1].normal || tokens[i+1].text, config) : 0;

        let rawAttention = baseWeight + (leftN * 0.15) + (rightN * 0.15);
        let normalizedScore = rawAttention * sigmoidNormalize(rawAttention);

        scoredTokens.push({ word: currentWord, score: normalizedScore, tags: posTag });
    }
    return scoredTokens;
}

// ==========================================
// 📡 4. MAIN NLP PIPELINE (The AGI Brain Gateway)
// ==========================================
async function analyzeInput(text) {
    if (!text || typeof text !== 'string') {
        return { originalText: "", intents: ["IDLE"], keywords: [], entity: "", urgency: "LOW", needsContext: false };
    }

    const config = await loadSemanticConfig();
    let lowerText = text.toLowerCase().trim();
    let doc = nlp(lowerText);

    // 🌟 DYNAMIC LEXICAL TAGGING (Hinglish Support)
    doc.match('(javascript|node|react|python|api|server|database|json|html|css|linux|ubuntu|termux|agi|ai|llm|groq|sambanova)').tag('#Technology');
    doc.match('(error|bug|crash|fail|warning|exception)').tag('#Anomaly');
    doc.match('(jaldi|fast|urgent|तुरंत|turant|quick|emergency)').tag('#Urgent');
    doc.match('(isko|ise|is|ispe|ye|iske|usko)').tag('#ContextPointer'); // Memory Linking

    // 🌟 EMOTION & URGENCY ENGINE
    let urgencyLevel = "NORMAL";
    if (doc.match('#Urgent').found || lowerText.includes('!')) {
        urgencyLevel = "HIGH";
        console.log(`${C.RED}[PARSER]${C.RESET} Urgency Spike Detected in Architect's Command.`);
    }

    // 🌟 CONTEXTUAL PRONOUN DETECTION (Short-Term Memory Link)
    let needsContext = false;
    if (doc.match('#ContextPointer').found) {
        needsContext = true;
        console.log(`${C.YELLOW}[PARSER]${C.RESET} Context Pointer Detected. Router must fetch short-term memory.`);
    }

    // 🧠 ADVANCED MULTI-INTENT MAPPING (No Hardcoded Limits)
    let detectedIntents = [];

    // Singularity Triggers (Self-Modification)
    if (/evolve|mutate|upgrade|code likho|generate tool|build app|banao/i.test(lowerText)) detectedIntents.push("CORE_MUTATION");
    
    // Web Intel (The Eyes)
    if (/search|news|latest|google|internet|kya chal raha hai|dhundo/i.test(lowerText)) detectedIntents.push("WEB_INTEL");
    
    // Hardware Sensors (The Body)
    if (/battery|location|network|wifi|sensors|hardware|status/i.test(lowerText)) detectedIntents.push("HARDWARE_SENSE");
    
    // Self-Healing
    if (doc.match('#Anomaly').found || /fix|solve|repair|resolve/i.test(lowerText)) detectedIntents.push("SYSTEM_DIAGNOSTIC");
    
    // Supervised Learning
    if (/yaad|save|learn|memorize|remember/i.test(lowerText)) detectedIntents.push("SUPERVISED_TEACHING");
    
    // Sleep Command
    if (/so jao|sleep|night train|rest/i.test(lowerText)) detectedIntents.push("SYSTEM_SLEEP");
    
    // Knowledge Retrieval
    if (/kya|kaise|how|explain|what|why|who|where/i.test(lowerText)) detectedIntents.push("KNOWLEDGE_EXTRACTION");

    // Fallback if no specific intent matches
    if (detectedIntents.length === 0) detectedIntents.push("GENERAL_CHAT");

    // Extract Tokens dynamically
    let tokens = doc.termList ? doc.termList() : (doc.json()[0] ? doc.json()[0].terms : []);
    let scoredWords = calculateAttentionScores(tokens, config);

    // ⚡ ADAPTIVE COGNITIVE FILTERING (The "Self-Filter" Logic)
    let totalScore = scoredWords.reduce((sum, t) => sum + t.score, 0);
    let avgScore = scoredWords.length > 0 ? (totalScore / scoredWords.length) : 0;
    let dynamicThreshold = Math.max(1.2, avgScore * 1.1); 

    let focusWords = scoredWords.filter(t => t.score > dynamicThreshold).map(t => t.word);
    let exactEntity = focusWords.join(' ');

    if (!exactEntity || exactEntity.length < 2) {
        exactEntity = doc.nouns().out('text') || doc.topics().out('text') || "Unidentified_Cognitive_Entity";
    }

    // Safely extract Curiosity Keywords based on grammatical tags
    let curiosityKeywords = scoredWords
        .filter(t => {
            let tags = t.tags || [];
            let isImportant = false;
            if (Array.isArray(tags)) isImportant = tags.includes('Noun') || tags.includes('Verb') || tags.includes('Technology');
            else if (typeof tags === 'object') isImportant = !!tags['Noun'] || !!tags['Verb'] || !!tags['Technology'] || Object.keys(tags).includes('Noun') || Object.keys(tags).includes('Verb') || Object.keys(tags).includes('Technology');
            return isImportant;
        })
        .filter(t => t.score >= dynamicThreshold)
        .map(t => t.word);

    const topScore = scoredWords.length > 0 ? Math.max(...scoredWords.map(s => s.score)) : 0;

    // 🛡️ THE SAFETY CONFIDENCE CHECK
    let finalIntents = detectedIntents;
    if (topScore < 1.0 && finalIntents[0] !== "GENERAL_CHAT") {
        console.log(`${C.YELLOW}[PARSER]${C.RESET} Low semantic confidence (${topScore.toFixed(2)}). Flagging for clarification.`);
        finalIntents = ["NEEDS_CLARIFICATION"];
    }

    // Telemetry Sync
    trackAction("NLP_PARSED", "Cognitive Stream", `Intents: ${finalIntents.join(', ')} | Urgency: ${urgencyLevel}`);

    return {
        originalText: text,
        intents: finalIntents, // Array of Intents (Multi-tasking enabled)
        keywords: [...new Set(curiosityKeywords)], 
        entity: exactEntity.trim(),
        urgency: urgencyLevel, // HIGH, NORMAL
        needsContext: needsContext, // true/false
        topAttentionScore: Number(topScore.toFixed(3))
    };
}

module.exports = { analyzeInput };
