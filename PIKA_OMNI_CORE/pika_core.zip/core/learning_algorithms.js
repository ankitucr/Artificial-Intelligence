const express = require('express');
const app = express();
const { Graph, Node, Edge } = require('graphology');
const graph = new Graph();

class KnowledgeGraph {
  constructor() {
    this.graph = graph;
  }

  async expandNode(nodeId, depth = 1) {
    const node = this.graph.getNode(nodeId);
    if (!node) return;

    const neighbors = this.graph.getNeighbors(nodeId);
    for (const neighbor of neighbors) {
      const edge = this.graph.getEdge(nodeId, neighbor);
      if (edge) {
        const weight = edge.weight;
        const newNode = new Node(neighbor, { weight });
        this.graph.addNode(newNode);
      }
    }

    if (depth > 0) {
      for (const neighbor of neighbors) {
        await this.expandNode(neighbor, depth - 1);
      }
    }
  }

  async addNode(nodeId, attributes) {
    const node = new Node(nodeId, attributes);
    this.graph.addNode(node);
  }

  async addEdge(from, to, attributes) {
    const edge = new Edge(from, to, attributes);
    this.graph.addEdge(edge);
  }

  async getNeighbors(nodeId) {
    return this.graph.getNeighbors(nodeId);
  }

  async getEdges(nodeId) {
    return this.graph.getEdges(nodeId);
  }

  async getShortestPath(from, to) {
    return this.graph.getShortestPath(from, to);
  }

  async getConnectedComponents() {
    return this.graph.getConnectedComponents();
  }
}

const knowledgeGraph = new KnowledgeGraph();

app.use(express.json());

app.post('/expand-node', async (req, res) => {
  const nodeId = req.body.nodeId;
  const depth = req.body.depth;
  await knowledgeGraph.expandNode(nodeId, depth);
  res.send(`Node ${nodeId} expanded`);
});

app.post('/add-node', async (req, res) => {
  const nodeId = req.body.nodeId;
  const attributes = req.body.attributes;
  await knowledgeGraph.addNode(nodeId, attributes);
  res.send(`Node ${nodeId} added`);
});

app.post('/add-edge', async (req, res) => {
  const from = req.body.from;
  const to = req.body.to;
  const attributes = req.body.attributes;
  await knowledgeGraph.addEdge(from, to, attributes);
  res.send(`Edge from ${from} to ${to} added`);
});

app.get('/get-neighbors', async (req, res) => {
  const nodeId = req.query.nodeId;
  const neighbors = await knowledgeGraph.getNeighbors(nodeId);
  res.send(neighbors);
});

app.get('/get-edges', async (req, res) => {
  const nodeId = req.query.nodeId;
  const edges = await knowledgeGraph.getEdges(nodeId);
  res.send(edges);
});

app.get('/get-shortest-path', async (req, res) => {
  const from = req.query.from;
  const to = req.query.to;
  const path = await knowledgeGraph.getShortestPath(from, to);
  res.send(path);
});

app.get('/get-connected-components', async (req, res) => {
  const components = await knowledgeGraph.getConnectedComponents();
  res.send(components);
});

app.listen(3000, () => {
  console.log('Server listening on port 3000');
});