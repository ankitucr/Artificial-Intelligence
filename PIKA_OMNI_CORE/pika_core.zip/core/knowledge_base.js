const express = require('express');
const app = express();
const port = 3000;

let domainKnowledge = {
  "entities": [
    { "id": 1, "name": "Entity1", "description": "This is entity 1" },
    { "id": 2, "name": "Entity2", "description": "This is entity 2" }
  ],
  "relationships": [
    { "id": 1, "entity1Id": 1, "entity2Id": 2, "type": "related to" }
  ]
};

let semanticReasoning = {
  "rules": [
    { "id": 1, "pattern": "Entity1 related to Entity2", "conclusion": "Entity1 and Entity2 are related" }
  ]
};

let expandedDomainKnowledge = {
  "entities": [
    { "id": 1, "name": "Entity1", "description": "This is entity 1", "attributes": ["attribute1", "attribute2"] },
    { "id": 2, "name": "Entity2", "description": "This is entity 2", "attributes": ["attribute3", "attribute4"] },
    { "id": 3, "name": "Entity3", "description": "This is entity 3", "attributes": ["attribute5", "attribute6"] }
  ],
  "relationships": [
    { "id": 1, "entity1Id": 1, "entity2Id": 2, "type": "related to", "strength": 0.8 },
    { "id": 2, "entity1Id": 1, "entity2Id": 3, "type": "related to", "strength": 0.4 },
    { "id": 3, "entity1Id": 2, "entity2Id": 3, "type": "related to", "strength": 0.6 }
  ]
};

let enhancedSemanticReasoning = {
  "rules": [
    { "id": 1, "pattern": "Entity1 related to Entity2", "conclusion": "Entity1 and Entity2 are related", "confidence": 0.9 },
    { "id": 2, "pattern": "Entity1 has attribute1", "conclusion": "Entity1 is a type of entity with attribute1", "confidence": 0.8 },
    { "id": 3, "pattern": "Entity2 related to Entity3", "conclusion": "Entity2 and Entity3 are related", "confidence": 0.7 }
  ]
};

app.use(express.json());

app.get('/domain-knowledge', (req, res) => {
  res.json(domainKnowledge);
});

app.get('/semantic-reasoning', (req, res) => {
  res.json(semanticReasoning);
});

app.get('/query', (req, res) => {
  let query = req.query.query;
  let results = [];

  for (let rule of semanticReasoning.rules) {
    if (query.includes(rule.pattern)) {
      results.push(rule.conclusion);
    }
  }

  res.json(results);
});

app.get('/expanded-domain-knowledge', (req, res) => {
  res.json(expandedDomainKnowledge);
});

app.get('/enhanced-semantic-reasoning', (req, res) => {
  res.json(enhancedSemanticReasoning);
});

app.get('/advanced-query', (req, res) => {
  let query = req.query.query;
  let results = [];

  for (let rule of enhancedSemanticReasoning.rules) {
    if (query.includes(rule.pattern)) {
      results.push({ "conclusion": rule.conclusion, "confidence": rule.confidence });
    }
  }

  res.json(results);
});

app.get('/entity-relationships', (req, res) => {
  let entityId = req.query.entityId;
  let relationships = [];

  for (let relationship of expandedDomainKnowledge.relationships) {
    if (relationship.entity1Id == entityId || relationship.entity2Id == entityId) {
      relationships.push(relationship);
    }
  }

  res.json(relationships);
});

app.get('/entity-attributes', (req, res) => {
  let entityId = req.query.entityId;
  let entity = expandedDomainKnowledge.entities.find(entity => entity.id == entityId);

  if (entity) {
    res.json(entity.attributes);
  } else {
    res.json([]);
  }
});

app.get('/entity-attributes-with-confidence', (req, res) => {
  let entityId = req.query.entityId;
  let entity = expandedDomainKnowledge.entities.find(entity => entity.id == entityId);

  if (entity) {
    let attributesWithConfidence = entity.attributes.map(attribute => {
      let confidence = 0.5; // default confidence
      for (let rule of enhancedSemanticReasoning.rules) {
        if (rule.pattern.includes(attribute)) {
          confidence = rule.confidence;
        }
      }
      return { "attribute": attribute, "confidence": confidence };
    });
    res.json(attributesWithConfidence);
  } else {
    res.json([]);
  }
});

app.get('/entity-relationships-with-confidence', (req, res) => {
  let entityId = req.query.entityId;
  let relationships = [];

  for (let relationship of expandedDomainKnowledge.relationships) {
    if (relationship.entity1Id == entityId || relationship.entity2Id == entityId) {
      let confidence = relationship.strength;
      for (let rule of enhancedSemanticReasoning.rules) {
        if (rule.pattern.includes(relationship.type)) {
          confidence = rule.confidence;
        }
      }
      relationships.push({ "relationship": relationship, "confidence": confidence });
    }
  }

  res.json(relationships);
});

app.get('/query-with-confidence', (req, res) => {
  let query = req.query.query;
  let results = [];

  for (let rule of enhancedSemanticReasoning.rules) {
    if (query.includes(rule.pattern)) {
      results.push({ "conclusion": rule.conclusion, "confidence": rule.confidence });
    }
  }

  res.json(results);
});

app.get('/entity-description', (req, res) => {
  let entityId = req.query.entityId;
  let entity = expandedDomainKnowledge.entities.find(entity => entity.id == entityId);

  if (entity) {
    res.json(entity.description);
  } else {
    res.json("Entity not found");
  }
});

app.get('/entity-related-entities', (req, res) => {
  let entityId = req.query.entityId;
  let relatedEntities = [];

  for (let relationship of expandedDomainKnowledge.relationships) {
    if (relationship.entity1Id == entityId) {
      relatedEntities.push(expandedDomainKnowledge.entities.find(entity => entity.id == relationship.entity2Id));
    } else if (relationship.entity2Id == entityId) {
      relatedEntities.push(expandedDomainKnowledge.entities.find(entity => entity.id == relationship.entity1Id));
    }
  }

  res.json(relatedEntities);
});

app.get('/entity-related-entities-with-confidence', (req, res) => {
  let entityId = req.query.entityId;
  let relatedEntities = [];

  for (let relationship of expandedDomainKnowledge.relationships) {
    if (relationship.entity1Id == entityId) {
      let confidence = relationship.strength;
      for (let rule of enhancedSemanticReasoning.rules) {
        if (rule.pattern.includes(relationship.type)) {
          confidence = rule.confidence;
        }
      }
      relatedEntities.push({ "entity": expandedDomainKnowledge.entities.find(entity => entity.id == relationship.entity2Id), "confidence": confidence });
    } else if (relationship.entity2Id == entityId) {
      let confidence = relationship.strength;
      for (let rule of enhancedSemanticReasoning.rules) {
        if (rule.pattern.includes(relationship.type)) {
          confidence = rule.confidence;
        }
      }
      relatedEntities.push({ "entity": expandedDomainKnowledge.entities.find(entity => entity.id == relationship.entity1Id), "confidence": confidence });
    }
  }

  res.json(relatedEntities);
});

app.post('/add-entity', (req, res) => {
  let entity = req.body;
  expandedDomainKnowledge.entities.push(entity);
  res.json(expandedDomainKnowledge.entities);
});

app.post('/add-relationship', (req, res) => {
  let relationship = req.body;
  expandedDomainKnowledge.relationships.push(relationship);
  res.json(expandedDomainKnowledge.relationships);
});

app.post('/add-rule', (req, res) => {
  let rule = req.body;
  enhancedSemanticReasoning.rules.push(rule);
  res.json(enhancedSemanticReasoning.rules);
});

app.get('/entity-attribute-values', (req, res) => {
  let entityId = req.query.entityId;
  let entity = expandedDomainKnowledge.entities.find(entity => entity.id == entityId);

  if (entity) {
    let attributeValues = {};
    for (let attribute of entity.attributes) {
      attributeValues[attribute] = [];
      for (let relationship of expandedDomainKnowledge.relationships) {
        if (relationship.entity1Id == entityId || relationship.entity2Id == entityId) {
          let relatedEntity = expandedDomainKnowledge.entities.find(e => e.id == (relationship.entity1Id == entityId ? relationship.entity2Id : relationship.entity1Id));
          if (relatedEntity.attributes.includes(attribute)) {
            attributeValues[attribute].push(relatedEntity.name);
          }
        }
      }
    }
    res.json(attributeValues);
  } else {
    res.json({});
  }
});

app.get('/entity-relationship-values', (req, res) => {
  let entityId = req.query.entityId;
  let relationships = [];

  for (let relationship of expandedDomainKnowledge.relationships) {
    if (relationship.entity1Id == entityId || relationship.entity2Id == entityId) {
      let relatedEntity = expandedDomainKnowledge.entities.find(entity => entity.id == (relationship.entity1Id == entityId ? relationship.entity2Id : relationship.entity1Id));
      relationships.push({ "relationship": relationship.type, "relatedEntity": relatedEntity.name });
    }
  }

  res.json(relationships);
});

app.get('/entity-relationship-values-with-confidence', (req, res) => {
  let entityId = req.query.entityId;
  let relationships = [];

  for (let relationship of expandedDomainKnowledge.relationships) {
    if (relationship.entity1Id == entityId || relationship.entity2Id == entityId) {
      let confidence = relationship.strength;
      for (let rule of enhancedSemanticReasoning.rules) {
        if (rule.pattern.includes(relationship.type)) {
          confidence = rule.confidence;
        }
      }
      let relatedEntity = expandedDomainKnowledge.entities.find(entity => entity.id == (relationship.entity1Id == entityId ? relationship.entity2Id : relationship.entity1Id));
      relationships.push({ "relationship": relationship.type, "relatedEntity": relatedEntity.name, "confidence": confidence });
    }
  }

  res.json(relationships);
});

app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});