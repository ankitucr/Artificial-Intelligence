const natural = require('natural');
const express = require('express');
const app = express();
const port = 3000;

let tokenizer = new natural.WordTokenizer();
let language = "EN";
let lexicon = new natural.Lexicon(language);
let ruleSet = new natural.RuleSet(language);
let tagger = new natural.BrillPOSTagger(lexicon, ruleSet);

app.use(express.json());

app.post('/process', (req, res) => {
    let text = req.body.text;
    let tokens = tokenizer.tokenize(text);
    let taggedTokens = tagger.tag(tokens);
    let result = [];

    for (let i = 0; i < taggedTokens.length; i++) {
        let token = taggedTokens[i][0];
        let tag = taggedTokens[i][1];
        result.push({ token, tag });
    }

    res.json(result);
});

app.listen(port, () => {
    console.log(`Server started on port ${port}`);
});

const improveContextualUnderstanding = (text) => {
    let contextualTokens = tokenizer.tokenize(text);
    let contextualTaggedTokens = tagger.tag(contextualTokens);
    let contextualResult = [];

    for (let i = 0; i < contextualTaggedTokens.length; i++) {
        let contextualToken = contextualTaggedTokens[i][0];
        let contextualTag = contextualTaggedTokens[i][1];
        contextualResult.push({ token: contextualToken, tag: contextualTag });
    }

    return contextualResult;
};

app.post('/improve', (req, res) => {
    let text = req.body.text;
    let improvedResult = improveContextualUnderstanding(text);
    res.json(improvedResult);
});