const natural = require('natural');
const express = require('express');
const app = express();
const port = 3000;

let context = {};
let intentMap = {
  'greeting': 'Hello, how can I assist you today?',
  'goodbye': 'It was nice talking to you. Goodbye!',
  'thanks': 'You\'re welcome!'
};

app.use(express.json());

app.post('/converse', (req, res) => {
  const userInput = req.body.input;
  const tokenizer = new natural.WordTokenizer();
  const tokens = tokenizer.tokenize(userInput);
  const language = 'EN';
  const lexicon = new natural.Lexicon(language);
  const ruleSet = new natural.RuleSet(language);
  const tagger = new natural.BrillPOSTagger(lexicon, ruleSet);
  const taggedTokens = tagger.tag(tokens);

  let intent = '';
  for (let i = 0; i < taggedTokens.length; i++) {
    if (taggedTokens[i][1] === 'NN' || taggedTokens[i][1] === 'VB') {
      intent += taggedTokens[i][0] + ' ';
    }
  }

  intent = intent.trim().toLowerCase();
  if (intentMap[intent]) {
    context[intent] = true;
    res.send({ response: intentMap[intent] });
  } else {
    res.send({ response: 'I didn\'t understand that. Could you please rephrase?' });
  }
});

app.post('/context', (req, res) => {
  const userInput = req.body.input;
  const tokenizer = new natural.WordTokenizer();
  const tokens = tokenizer.tokenize(userInput);
  const language = 'EN';
  const lexicon = new natural.Lexicon(language);
  const ruleSet = new natural.RuleSet(language);
  const tagger = new natural.BrillPOSTagger(lexicon, ruleSet);
  const taggedTokens = tagger.tag(tokens);

  let entities = [];
  for (let i = 0; i < taggedTokens.length; i++) {
    if (taggedTokens[i][1] === 'NNP' || taggedTokens[i][1] === 'NNPS') {
      entities.push(taggedTokens[i][0]);
    }
  }

  context[entities.join(' ')] = true;
  res.send({ response: 'Context updated successfully' });
});

app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});