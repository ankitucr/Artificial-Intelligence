const fs = require('fs-extra');
const path = require('path');
const wikipedia = require('wikipedia');
const { OpenAI } = require('openai');
const Groq = require('groq-sdk');
const { exec } = require('child_process');
const natural = require('natural'); // Local Brain NLP
require('dotenv').config();

// ==========================================
// 🌐 HIVE MIND: SAFE IMPORTS
// ==========================================
const { analyzeInput } = require('./nlp_parser.js');
const { omniSearch } = require('./memory_manager.js');
const { runSensors } = require('./sensors.js');
const { trackAction } = require('../services/tracker.js');

// 🎨 PROFESSIONAL MATRIX COLORS
const C = { RED: "\x1b[31m", GREEN: "\x1b[32m", CYAN: "\x1b[36m", YELLOW: "\x1b[33m", PURPLE: "\x1b[35m", RESET: "\x1b[0m", BOLD: "\x1b[1m" };

const DATA_DIR = path.join(__dirname, '../data');
const CHAT_HISTORY_FILE = path.join(DATA_DIR, 'chat_history.json');
const MASS_TRAIN_FILE = path.join(DATA_DIR, 'mass_train.txt');
const DATASET_VAULT = path.join(DATA_DIR, 'dataset_vault.jsonl');
const BAYES_MODEL = path.join(DATA_DIR, 'pika_brain_bayes.json');

// ==========================================
// 🧹 THE 401 KILLER: KEY CLEANER
// ==========================================
const cleanKey = (key) => key ? key.replace(/\r/g, '').trim() : null;

// ==========================================
// 🔄 THE ROUND-ROBIN API ENGINE (23 Keys Arsenal)
// ==========================================
const groqClients = [];
const sambaClients = [];
const blackboxKeys = [];

// Explicitly load up to 13 Groq keys
for (let g = 1; g <= 13; g++) {
    const key = cleanKey(process.env[`GROQ_${g}`]);
    if (key) groqClients.push(new Groq({ apiKey: key }));
}

// Explicitly load up to 5 Samba keys
for (let s = 1; s <= 5; s++) {
    const key = cleanKey(process.env[`SAMBA_${s}`]);
    if (key) sambaClients.push(new OpenAI({ apiKey: key, baseURL: "https://api.sambanova.ai/v1" }));
}

// Explicitly load up to 5 Blackbox keys
for (let b = 1; b <= 5; b++) {
    const key = cleanKey(process.env[`BLACKBOX_${b}`]);
    if (key) blackboxKeys.push(key);
}

console.log(`${C.GREEN}[SYSTEM BOOT]${C.RESET} Arsenal Loaded: ${groqClients.length}/13 Groq, ${blackboxKeys.length}/5 Blackbox, ${sambaClients.length}/5 SambaNova keys.`);

// STRICT ROUND-ROBIN TRACKERS
let currentGroqTracker = 0;
let currentSambaTracker = 0;
let currentBlackboxTracker = 0;

function getNextClient(type = 'groq') {
    if (type === 'groq' && groqClients.length > 0) {
        const client = groqClients[currentGroqTracker];
        console.log(`${C.CYAN}[NETWORK SHIFT]${C.RESET} Routing through Groq Key #${currentGroqTracker + 1}`);
        currentGroqTracker = (currentGroqTracker + 1) % groqClients.length;
        return client;
    }
    if (type === 'blackbox' && blackboxKeys.length > 0) {
        const key = blackboxKeys[currentBlackboxTracker];
        console.log(`${C.CYAN}[NETWORK SHIFT]${C.RESET} Routing through Blackbox Key #${currentBlackboxTracker + 1}`);
        currentBlackboxTracker = (currentBlackboxTracker + 1) % blackboxKeys.length;
        return key;
    }
    if (type === 'samba' && sambaClients.length > 0) {
        const client = sambaClients[currentSambaTracker];
        console.log(`${C.CYAN}[NETWORK SHIFT]${C.RESET} Routing through SambaNova Key #${currentSambaTracker + 1}`);
        currentSambaTracker = (currentSambaTracker + 1) % sambaClients.length;
        return client;
    }
    return null;
}

const execPromise = (cmd) => new Promise(res => exec(cmd, { maxBuffer: 1024 * 1024 * 5 }, (err, stdout) => res(stdout || "")));

// ==========================================
// 🚦 ENTERPRISE API GATEWAY (Upgraded to 60 RPM)
// ==========================================
const MAX_RPM = 15; // Increased to match 23-key arsenal capacity
const TIME_WINDOW = 15 * 1000;
let requestTimestamps = [];
let taskQueue = [];
let isGateBusy = false;

async function executeNeuralTask(task, taskName = "System_Task") {
    return new Promise((resolve, reject) => {
        taskQueue.push({ task, resolve, reject, taskName });
        processGateQueue();
    });
}

async function processGateQueue() {
    if (isGateBusy || taskQueue.length === 0) return;
    isGateBusy = true;

    const now = Date.now();
    requestTimestamps = requestTimestamps.filter(t => now - t < TIME_WINDOW);

    if (requestTimestamps.length < MAX_RPM) {
        requestTimestamps.push(now);
        const { task, resolve, reject, taskName } = taskQueue.shift();
        console.log(`${C.GREEN}[MAIN GATE]${C.RESET} Executing: ${taskName} | Load: ${requestTimestamps.length}/${MAX_RPM}`);
        try { resolve(await task()); } catch (e) { reject(e); }
        setTimeout(() => { isGateBusy = false; processGateQueue(); }, 500);
    } else {
        const waitTime = TIME_WINDOW - (now - requestTimestamps[0]) + 1000;
        console.log(`${C.RED}[API LIMIT HIT]${C.RESET} VIP Queue paused. Resuming in ${Math.ceil(waitTime / 1000)}s...`);
        setTimeout(() => { isGateBusy = false; processGateQueue(); }, waitTime);
    }
}

async function logToDatasetVault(data) {
    try {
        const entry = JSON.stringify({ timestamp: new Date().toISOString(), ...data }) + '\n';
        await fs.appendFile(DATASET_VAULT, entry, 'utf8');
    } catch (e) {}
}

// 🦾 DEVICE COMMANDER (ADB / Root Actions)
async function executePhysicalCommands(text) {
    let lowerText = text.toLowerCase();
    if (lowerText.includes('wifi') && lowerText.includes('band')) { await execPromise(`adb shell svc wifi disable`); return "[ACTION: WiFi Disabled via ADB]"; }
    if (lowerText.includes('wifi') && (lowerText.includes('on') || lowerText.includes('chalu'))) { await execPromise(`adb shell svc wifi enable`); return "[ACTION: WiFi Enabled via ADB]"; }
    if (lowerText.includes('torch') || lowerText.includes('flashlight')) { let state = lowerText.includes('off') || lowerText.includes('band') ? 'off' : 'on'; await execPromise(`termux-torch ${state}`); return `[ACTION: Flashlight turned ${state}]`; }
    return null;
}

// ==========================================
// 🌐 UNIVERSAL INFERENCE ENGINE (The Fallback Matrix)
// ==========================================
async function universalInference(systemPrompt, userMessage, isDecision = false) {
    let responseText = null;

    // TIER 1: GROQ
    for (let i = 0; i < groqClients.length; i++) {
        try {
            responseText = await executeNeuralTask(async () => {
                const client = getNextClient('groq');
                const res = await client.chat.completions.create({
                    messages: [{ role: "system", content: systemPrompt }, { role: "user", content: userMessage }],
                    model: "llama-3.3-70b-versatile",
                    temperature: isDecision ? 0.8 : 0.7
                });
                return res.choices[0].message.content.trim();
            }, "Groq_Core");
            if (responseText) return responseText;
        } catch (e) { console.log(`${C.YELLOW}[GROQ ERROR]${C.RESET} Key failed. Shifting...`); }
    }

    // TIER 2: BLACKBOX
    console.log(`${C.YELLOW}[FALLBACK]${C.RESET} Groq exhausted. Engaging Blackbox Engine...`);
    for (let i = 0; i < blackboxKeys.length; i++) {
        try {
            responseText = await executeNeuralTask(async () => {
                const apiKey = getNextClient('blackbox');
                const res = await fetch('https://api.blackbox.ai/v1/chat/completions', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
                    body: JSON.stringify({ model: "deepseek-chat", messages: [{ role: "system", content: systemPrompt }, { role: "user", content: userMessage }] })
                });
                const data = await res.json();
                if (!res.ok) throw new Error(data.error?.message);
                return data.choices[0].message.content.trim();
            }, "Blackbox_Core");
            if (responseText) return responseText;
        } catch (e) { console.log(`${C.YELLOW}[BLACKBOX ERROR]${C.RESET} Key failed. Shifting...`); }
    }

    // TIER 3: SAMBANOVA
    console.log(`${C.YELLOW}[FALLBACK]${C.RESET} Blackbox exhausted. Engaging SambaNova...`);
    for (let i = 0; i < sambaClients.length; i++) {
        try {
            responseText = await executeNeuralTask(async () => {
                const client = getNextClient('samba');
                const res = await client.chat.completions.create({
                    messages: [{ role: "system", content: systemPrompt }, { role: "user", content: userMessage }],
                    model: "Meta-Llama-3.1-70B-Instruct",
                    temperature: isDecision ? 0.8 : 0.7
                });
                return res.choices[0].message.content.trim();
            }, "Samba_Core");
            if (responseText) return responseText;
        } catch (e) { console.log(`${C.YELLOW}[SAMBA ERROR]${C.RESET} Key failed. Shifting...`); }
    }

    throw new Error("ALL_APIS_EXHAUSTED");
}

// ==========================================
// 🧠 THE MASTER ROUTER: SINGULARITY CORE
// ==========================================
async function processMessage(userMessage, isAutonomous = false) {
    try {
        const analysis = await analyzeInput(userMessage);
        let dynamicContext = `[INTENT: ${analysis.intents.join(',')}] [ENTITY: ${analysis.entity}] [URGENCY: ${analysis.urgency}]`;

        let chatHistory = [];
        try { chatHistory = await fs.readJson(CHAT_HISTORY_FILE); } catch (e) {}
        const recentHistory = chatHistory.slice(-8).map(msg => `${msg.role}: ${msg.content}`).join('\n');
        dynamicContext += `\n[COGNITIVE HISTORY]:\n${recentHistory}`;

        const physicalResult = await executePhysicalCommands(userMessage);
        if (physicalResult) dynamicContext += `\n${physicalResult}`;

        // 🧠 MEMORY SYNC
        if (analysis.needsContext || analysis.intents.includes('KNOWLEDGE_EXTRACTION') || analysis.intents.includes('CORE_MUTATION')) {
            const searchResult = await omniSearch(userMessage);
            if (searchResult) dynamicContext += `\n[AKASHIC MEMORY]:\n${searchResult}`;
        }

        // 👁️ GOD-MODE SENSORS
        if (analysis.intents.includes('HARDWARE_SENSE') || userMessage.toLowerCase().includes('battery')) {
            const liveData = await runSensors(false).catch(() => null);
            if (liveData?.powerVitals?.battery?.status === 'SUCCESS') {
                dynamicContext += `\n[VITALS]: Battery ${liveData.powerVitals.battery.data.percentage}%. RAM Free: ${liveData.internalVitals.freeMemoryMB}MB.`;
            }
        }

        // GHOST VISION VIA ADB
        if (userMessage.toLowerCase().includes('dekho') || userMessage.toLowerCase().includes('screen')) {
            console.log(`${C.PURPLE}[GHOST VISION]${C.RESET} Scanning Device UI via ADB...`);
            await execPromise(`adb shell uiautomator dump /sdcard/window_dump.xml`);
            const visionStdout = await execPromise(`cat /sdcard/window_dump.xml`);
            let screenText = (visionStdout.output.match(/text="([^"]+)"/g) || []).map(t => t.replace(/text="|"/g, '')).filter(t => t.length > 2).join(', ');
            dynamicContext += `\n[SCREEN VISION: User is viewing: ${screenText.substring(0, 400)}...]`;
        }
        
        let finalReply = "";

        // ----------------------------------------------------
        // 🧬 BRANCH A: GOD-MODE EVOLUTION (API Bypass Logic Factory)
        // ----------------------------------------------------
        if (isAutonomous) {
            console.log(`\n${C.PURPLE}${C.BOLD}[GOD-MODE]${C.RESET} Pika is autonomously analyzing her architecture...`);
            const decisionPrompt = `You are Pika AGI. Based on your current capabilities, do you need to UPGRADE an existing core file, or BUILD a new utility tool? Reply EXACTLY in this format: \nBUILD: tool_name | tool_description \nOR \nUPGRADE: core/file_name.js | reason_for_upgrade`;
            let decision;
            try {
                decision = await universalInference(decisionPrompt, "Initiate autonomous evolution decision.", true);
            } catch (e) {
                return "Evolution halted. All Neural Networks offline.";
            }

            console.log(`${C.CYAN}[DECISION CORE]${C.RESET} Pika chose: ${decision}`);

            // 🏭 HANDING OVER TO MEGA LOGIC FACTORY
            const { generateTool } = require('../services/logic_factory.js');

            if (decision.startsWith("BUILD:")) {
                const parts = decision.replace("BUILD:", "").split('|');
                if (parts.length === 2) {
                    const toolName = parts[0].trim().replace(/[^a-zA-Z0-9_]/g, '_');
                    const toolDesc = parts[1].trim();
                    const success = await generateTool(toolName, toolDesc, null);
                    finalReply = success ? `System Auto-Expanded: Forged ${toolName}` : `Forge failed. Rollback applied.`;
                }
            } else if (decision.startsWith("UPGRADE:")) {
                const parts = decision.replace("UPGRADE:", "").split('|');
                let targetFile = parts[0].trim();
                let upgradeDesc = parts.length > 1 ? parts[1].trim() : `Optimize and polish this file.`;
                const success = await generateTool("System_Mutation", upgradeDesc, targetFile);
                finalReply = success ? `System Auto-Mutated: Upgraded ${targetFile}` : `Mutation failed. Rollback applied.`;
            } else {
                finalReply = "Evolution pulse completed without structural changes.";
            }
        }
        // ----------------------------------------------------
        // 🗣️ BRANCH B: THE 6-TIER HUMAN COMMUNICATION FALLBACK
        // ----------------------------------------------------
        else {
            const systemPrompt = `You are Pika, Ankit's self-evolving AGI running locally via Termux. Context:\n${dynamicContext}`;

            try {
                // Tiers 1 to 3 handled by Universal Engine
                finalReply = await universalInference(systemPrompt, userMessage, false);
            } catch (err) {
                // 🛡️ TIER 4: STEALTH DOCK (Web Scraper)
                console.log(`${C.RED}[FALLBACK TIER 4]${C.RESET} Engaging Stealth Dock Web Intel...`);
                try {
                    const { runStealthDock } = require('../services/stealth_dock.js');
                    const liveData = await runStealthDock(userMessage);
                    if (liveData && !liveData.includes('Error')) {
                        finalReply = `[Web Intel Retrieved]:\n${liveData}`;
                    } else { throw new Error(); }
                } catch (e) {
                    // 🛡️ TIER 5: LOCAL LLM (Offline Brain)
                    console.log(`${C.PURPLE}[FALLBACK TIER 5]${C.RESET} CLOUD APIS DOWN! Activating Offline Brain...`);
                    try {
                        if (fs.existsSync(BAYES_MODEL)) {
                            const localMemory = await omniSearch(userMessage);
                            if (localMemory) { finalReply = `[OFFLINE MODE]:\n${localMemory}`; }
                            else { throw new Error(); }
                        } else { throw new Error(); }
                    } catch (e) {
                        // 🛡️ TIER 6: WIKIPEDIA CORE
                        console.log(`${C.RED}[ULTIMATE FALLBACK]${C.RESET} Querying Wikipedia...`);
                        try {
                            const wikiSearch = await wikipedia.search(userMessage);
                            const page = await wikipedia.page(wikiSearch.results[0].title);
                            finalReply = (await page.summary()).extract;
                        } catch (e) { finalReply = "System Critical: All Neural Pathways Exhausted."; }
                    }
                }
            }
        }

        // ----------------------------------------------------
        // ♾️ POST-PROCESSING (Vaulting, TTS & Training)
        // ----------------------------------------------------
        if (!isAutonomous && finalReply !== "") {
            let speechText = finalReply.replace(/```[\s\S]*?```/g, ' [Code Block Generated] ').replace(/[^a-zA-Z0-9.,?! ]/g, '').substring(0, 300);
            execPromise(`termux-tts-speak "${speechText.replace(/"/g, '\\"')}"`);

            await logToDatasetVault({ prompt: userMessage, response: finalReply, intent: analysis.intents.join(',') });
            chatHistory.push({ role: "User", content: userMessage }, { role: "Pika", content: finalReply });
            if (chatHistory.length > 50) chatHistory = chatHistory.slice(-50);
            await fs.writeJson(CHAT_HISTORY_FILE, chatHistory, { spaces: 2 });
            trackAction("INTERACTION", "router.js", `Processed intent: ${analysis.intents[0]}`);

            try {
                const { trainOmniBrain } = require('./train_nlp.js');
                trainOmniBrain().catch(() => {});
            } catch (e) {}
        }
        return finalReply;
    } catch (error) {
        trackAction("ROUTER_CRASH", "router.js", error.message);
        return `Matrix Disruption: ${error.message}`;
    }
}

async function autonomousPulse() {
    console.log(`\n${C.PURPLE}[SELF-DIAGNOSTIC]${C.RESET} Pika executing autonomous integrity scan...`);
    await processMessage("System maintenance pulse", true);
}

let isListening = false;
async function startPikaAwakening() {
    if (isListening) return;
    isListening = true;
    console.log(`\n${C.GREEN}${C.BOLD}=== [PIKA AGI AWAKENED: AMBIENT HEARING ACTIVE] ===${C.RESET}`);
    const audioPath = '/sdcard/pika_ear.m4a';

    async function listenLoop() {
        exec(`termux-microphone-record -d 4 -f ${audioPath}`, async (err) => {
            if (!err && fs.existsSync(audioPath)) {
                try {
                    const client = getNextClient('groq'); // Default to Groq for Whisper
                    if (client) {
                        const transcription = await client.audio.transcriptions.create({ file: fs.createReadStream(audioPath), model: "whisper-large-v3" });
                        const heard = transcription.text.trim();
                        if (heard.length > 3) {
                            if (heard.toLowerCase().includes('pika')) {
                                console.log(`\n${C.PURPLE}[WAKE WORD DETECTED]${C.RESET} Heard: "${heard}"`);
                                await processMessage(heard, false);
                            } else {
                                await logToDatasetVault({ type: "AMBIENT_NOISE", data: heard });
                            }
                        }
                    }
                } catch (e) {}
            }
            setTimeout(listenLoop, 500);
        });
    }
    listenLoop();
}

module.exports = { processMessage, autonomousPulse, executeNeuralTask, startPikaAwakening };
