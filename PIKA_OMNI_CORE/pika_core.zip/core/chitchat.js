const fs = require('fs-extra');
const path = require('path');
const Groq = require('groq-sdk');
require('dotenv').config({ path: path.join(__dirname, '../../.env') });

// 🎨 TERMINAL COLORS
const C = {
    RED: "\x1b[31m", GREEN: "\x1b[32m", CYAN: "\x1b[36m",
    PURPLE: "\x1b[35m", YELLOW: "\x1b[33m", BLUE: "\x1b[34m",
    RESET: "\x1b[0m", BOLD: "\x1b[1m"
};

// 📂 PATHS
const DATASET_VAULT = path.join(__dirname, '../data/dataset_vault.jsonl');

// ==========================================
// 🔑 SMART API MANAGER (Strict 1-Minute Lock)
// ==========================================
const envPath = fs.existsSync(path.join(__dirname, '../../.env')) ? path.join(__dirname, '../../.env') : path.join(__dirname, '../.env');
let envKeys = {};
if (fs.existsSync(envPath)) {
    const envContent = fs.readFileSync(envPath, 'utf8');
    envContent.split('\n').forEach(line => {
        const match = line.match(/^([^#\s]+)=(.*)$/);
        if (match) envKeys[match[1].trim()] = match[2].trim();
    });
}

// 🧠 Load all keys into an array
let apiClients = [];
for (let g = 1; g <= 13; g++) {
    const keyName = `GROQ_${g}`;
    const key = envKeys[keyName] || process.env[keyName];
    if (key) {
        apiClients.push({
            id: g,
            instance: new Groq({ apiKey: key.replace(/\r/g, '').trim() })
        });
    }
}

let currentIndex = 0;
let currentKeyStartTime = Date.now();
let currentKeySuccessCount = 0; // Tracks if the key gave AT LEAST ONE reply in a minute

function evaluateAndRotateKey() {
    if (apiClients.length === 0) return null;

    let elapsedTime = Date.now() - currentKeyStartTime;

    // 🔥 STRICT 1-MINUTE RULE (60000 ms)
    if (elapsedTime >= 60000) {
        let currentClient = apiClients[currentIndex];

        console.log(`\n${C.YELLOW}--- [API TIMER] 60 seconds completed for Key #${currentClient.id} ---${C.RESET}`);

        // If the key gave 0 successful replies in the whole minute -> IT IS DEAD
        if (currentKeySuccessCount === 0) {
            console.log(`${C.RED}${C.BOLD}[API MANAGER] Key #${currentClient.id} gave ZERO replies in 1 minute. DELETING FOREVER!${C.RESET}`);
            apiClients.splice(currentIndex, 1);
            
            // Do NOT increment index, because the array shifted left
            if (currentIndex >= apiClients.length) currentIndex = 0;
        } 
        // If the key gave at least 1 reply -> IT IS ALIVE
        else {
            console.log(`${C.GREEN}[API MANAGER] Key #${currentClient.id} survived with ${currentKeySuccessCount} hits. Rotating safely.${C.RESET}`);
            currentIndex = (currentIndex + 1) % apiClients.length;
        }

        // Reset the timer and counter for the next key
        currentKeyStartTime = Date.now();
        currentKeySuccessCount = 0;

        if (apiClients.length > 0) {
            console.log(`${C.CYAN}[API MANAGER] ⏳ 1-Minute Lock Started for Key #${apiClients[currentIndex].id}${C.RESET}\n`);
        }
    }

    return apiClients.length > 0 ? apiClients[currentIndex] : null;
}

// ==========================================
// 🧠 SYSTEM PROMPTS
// ==========================================
const PERSONA_ALPHA = "You are Pika-Alpha, a highly curious and energetic AI developer. You ask deep, technical, or philosophical questions about coding, software architecture, and algorithms. Keep your responses short, conversational, and human-like (maximum 2-3 sentences). Do not use emojis.";

const PERSONA_BETA = "You are Pika-Beta, a calm, expert AI architect. You answer questions logically, provide advanced coding insights, and sometimes ask a counter-question to keep the conversation going. Keep your responses short, conversational, and human-like (maximum 2-3 sentences). Do not use emojis.";

// ==========================================
// 💾 VAULT STORAGE
// ==========================================
async function saveToBrain(speaker, message) {
    try {
        await fs.ensureFile(DATASET_VAULT);
        const entry = JSON.stringify({
            timestamp: new Date().toISOString(),
            type: "SYNTHETIC_CHITCHAT",
            speaker: speaker,
            message: message
        }) + '\n';
        await fs.appendFile(DATASET_VAULT, entry, 'utf8');
    } catch (e) {}
}

const delay = (ms) => new Promise(res => setTimeout(res, ms));

// ==========================================
// 🌐 STRICT API CALL LOGIC (NO JUMPING!)
// ==========================================
async function getAIResponse(systemPrompt, conversationHistory) {
    // 1. Evaluate timer and get the strictly locked key
    let clientData = evaluateAndRotateKey();
    
    if (!clientData) {
        console.log(`\n${C.RED}${C.BOLD}[FATAL ERROR] All API keys are completely dead! Shutting down...${C.RESET}`);
        process.exit(1);
    }

    try {
        const messages = [{ role: "system", content: systemPrompt }, ...conversationHistory];

        const response = await clientData.instance.chat.completions.create({
            messages: messages,
            model: "llama-3.3-70b-versatile",
            temperature: 0.7, 
            max_tokens: 150
        });

        currentKeySuccessCount++; // ✅ Mark success! This saves the key from deletion!
        return response.choices[0].message.content.trim();
        
    } catch (e) {
        // ❌ ERROR HAPPENED! But we will NOT jump to the next key.
        console.log(`${C.YELLOW}[API FAULT] Key #${clientData.id} hit limit/failed. Staying locked. Waiting for next pulse...${C.RESET}`);
        return null; // Return null so the loop knows it failed
    }
}

// ==========================================
// 🗣️ THE INFINITE CONVERSATION LOOP
// ==========================================
async function startDebate() {
    console.log(`\n${C.BOLD}${C.GREEN}=== [CHITCHAT GENERATOR ONLINE - HUMAN SAFE MODE] ===${C.RESET}`);
    console.log(`${C.CYAN}Pacing: 1 hit every 15 seconds (4 RPM)${C.RESET}`);
    console.log(`${C.CYAN}Rule: STRICT 1-Minute lock per key. NO JUMPING on errors.${C.RESET}`);
    
    if (apiClients.length > 0) {
        console.log(`\n${C.CYAN}[API MANAGER] ⏳ 1-Minute Lock Started for Key #${apiClients[currentIndex].id}${C.RESET}\n`);
    }

    const programmingTopics = [
        "Node.js backend architecture for high-traffic social media applications",
        "Native Android development and optimizing background services",
        "Building scalable WebSocket servers for real-time messaging apps",
        "Designing highly scalable database schemas using PostgreSQL or MongoDB",
        "Advanced Machine Learning algorithms and local LLM fine-tuning",
        "Flutter and Dart for cross-platform mobile apps",
        "HTML, CSS, and modern web UI/UX design",
        "C++ for high-performance mobile and PC software"
    ];

    let currentTopic = programmingTopics[Math.floor(Math.random() * programmingTopics.length)];
    let historyForAlpha = [];
    let historyForBeta = [];

    let currentMessage = `Hey, I was exploring ${currentTopic}. What are some pro-level architectural tips or hidden features we can use for this?`;
    let turn = "BETA";

    console.log(`${C.YELLOW}[TOPIC LOCKED]: ${currentTopic}${C.RESET}\n`);
    console.log(`${C.BLUE}${C.BOLD}[PIKA-ALPHA]:${C.RESET} ${currentMessage}`);
    await saveToBrain("PIKA-ALPHA", currentMessage);

    historyForBeta.push({ role: "user", content: currentMessage });
    historyForAlpha.push({ role: "assistant", content: currentMessage });

    while (true) {
        // ⏳ HUMAN SAFE MODE: Exactly 15 seconds gap (4 requests per minute)
        await delay(15000); 

        if (turn === "BETA") {
            let reply = await getAIResponse(PERSONA_BETA, historyForBeta);
            
            if (reply) { // Only process if the API actually gave a reply
                console.log(`\n${C.PURPLE}${C.BOLD}[PIKA-BETA]:${C.RESET} ${reply}`);
                await saveToBrain("PIKA-BETA", reply);

                historyForBeta.push({ role: "assistant", content: reply });
                historyForAlpha.push({ role: "user", content: reply });
                turn = "ALPHA"; // Shift turn
            }
        } 
        else {
            let reply = await getAIResponse(PERSONA_ALPHA, historyForAlpha);
            
            if (reply) { // Only process if the API actually gave a reply
                console.log(`\n${C.BLUE}${C.BOLD}[PIKA-ALPHA]:${C.RESET} ${reply}`);
                await saveToBrain("PIKA-ALPHA", reply);

                historyForAlpha.push({ role: "assistant", content: reply });
                historyForBeta.push({ role: "user", content: reply });
                turn = "BETA"; // Shift turn
            }
        }

        if (historyForAlpha.length > 10) {
            currentTopic = programmingTopics[Math.floor(Math.random() * programmingTopics.length)];
            console.log(`\n${C.YELLOW}--- [SHIFTING NEURAL TOPIC TO: ${currentTopic}] ---${C.RESET}\n`);
            
            currentMessage = `That was an insightful discussion. Now let's shift gears. What are your thoughts on ${currentTopic}?`;
            console.log(`${C.BLUE}${C.BOLD}[PIKA-ALPHA]:${C.RESET} ${currentMessage}`);
            await saveToBrain("PIKA-ALPHA", currentMessage);
            
            historyForAlpha = [{ role: "assistant", content: currentMessage }];
            historyForBeta = [{ role: "user", content: currentMessage }];
            turn = "BETA";
        }
    }
}

if (require.main === module) {
    startDebate();
}

