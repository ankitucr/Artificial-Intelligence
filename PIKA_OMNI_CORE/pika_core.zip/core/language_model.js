const natural = require('natural');
const tokenizer = new natural.WordTokenizer();
const language = "EN";
const spellcheck = new natural.Spellcheck(language);
const TfIdf = new natural.TfIdf();
const PorterStemmer = natural.PorterStemmer;
const wordnet = new natural.WordNet();

class NLPProcessor {
  constructor() {
    this.stopwords = natural.stopwords;
  }

  tokenizeText(text) {
    return tokenizer.tokenize(text);
  }

  removeStopwords(tokens) {
    return tokens.filter(token => !this.stopwords.includes(token.toLowerCase()));
  }

  stemTokens(tokens) {
    return tokens.map(token => PorterStemmer.stem(token));
  }

  spellcheckText(text) {
    return spellcheck.getCorrections(text, 1);
  }

  calculateTfIdf(documents) {
    TfIdf.addDocument(documents[0]);
    TfIdf.addDocument(documents[1]);
    const list1 = TfIdf.listTerms(0);
    const list2 = TfIdf.listTerms(1);
    return { list1, list2 };
  }

  getSynonyms(word) {
    return wordnet.lookup(word);
  }
}

const processor = new NLPProcessor();

const text = "This is a sample text for natural language processing.";
const tokens = processor.tokenizeText(text);
const filteredTokens = processor.removeStopwords(tokens);
const stemmedTokens = processor.stemTokens(filteredTokens);
const spellcheckedText = processor.spellcheckText(text);
const documents = ["This is a sample document.", "This document is another sample."];
const tfIdfResult = processor.calculateTfIdf(documents);
const synonyms = processor.getSynonyms("sample");

console.log(tokens);
console.log(filteredTokens);
console.log(stemmedTokens);
console.log(spellcheckedText);
console.log(tfIdfResult);
console.log(synonyms);