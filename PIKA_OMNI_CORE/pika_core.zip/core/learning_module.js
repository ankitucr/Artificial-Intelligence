const express = require('express');
const app = express();
const { v4: uuidv4 } = require('uuid');
const { Graph, Node, Edge } = require('graphology');
const graph = new Graph();

class KnowledgeGraph {
  constructor() {
    this.graph = graph;
  }

  addNode(nodeId, nodeData) {
    if (!this.graph.hasNode(nodeId)) {
      this.graph.addNode(nodeId, nodeData);
    }
  }

  addEdge(edgeId, source, target, edgeData) {
    if (!this.graph.hasEdge(edgeId)) {
      this.graph.addEdge(edgeId, source, target, edgeData);
    }
  }

  expandGraph(newNodeData, newEdgeData) {
    const newNodeId = uuidv4();
    this.addNode(newNodeId, newNodeData);

    newEdgeData.forEach((edge) => {
      const edgeId = uuidv4();
      this.addEdge(edgeId, newNodeId, edge.target, edge.data);
    });
  }

  adaptToDynamicEnvironment(updatedNodeData, updatedEdgeData) {
    updatedNodeData.forEach((node) => {
      if (this.graph.hasNode(node.id)) {
        this.graph.setNodeAttribute(node.id, 'data', node.data);
      }
    });

    updatedEdgeData.forEach((edge) => {
      if (this.graph.hasEdge(edge.id)) {
        this.graph.setEdgeAttribute(edge.id, 'data', edge.data);
      }
    });
  }

  queryGraph(query) {
    const results = [];
    this.graph.forEachNode((node) => {
      if (node.data.includes(query)) {
        results.push(node);
      }
    });
    return results;
  }

  getShortestPath(source, target) {
    const shortestPath = this.graph.getShortestPath(source, target);
    return shortestPath;
  }

  getNeighbors(nodeId) {
    const neighbors = this.graph.getNeighbors(nodeId);
    return neighbors;
  }

  getGraphSize() {
    return this.graph.order;
  }

  getGraphDensity() {
    return this.graph.size / (this.graph.order * (this.graph.order - 1));
  }

  getCentrality(nodeId) {
    const centrality = this.graph.getCentrality(nodeId);
    return centrality;
  }

  getClusterCoefficient(nodeId) {
    const clusterCoefficient = this.graph.getClusterCoefficient(nodeId);
    return clusterCoefficient;
  }

  getCommunityStructure() {
    const communityStructure = this.graph.getCommunityStructure();
    return communityStructure;
  }

  getGraphData() {
    const graphData = {
      nodes: this.graph.nodes(),
      edges: this.graph.edges(),
    };
    return graphData;
  }

  getGraphStatistics() {
    const graphStatistics = {
      nodes: this.graph.order,
      edges: this.graph.size,
      density: this.getGraphDensity(),
    };
    return graphStatistics;
  }

  getConnectedComponents() {
    const connectedComponents = this.graph.getConnectedComponents();
    return connectedComponents;
  }

  getStronglyConnectedComponents() {
    const stronglyConnectedComponents = this.graph.getStronglyConnectedComponents();
    return stronglyConnectedComponents;
  }
}

const knowledgeGraph = new KnowledgeGraph();

app.use(express.json());

app.post('/expand-graph', (req, res) => {
  try {
    const newNodeData = req.body.newNodeData;
    const newEdgeData = req.body.newEdgeData;
    knowledgeGraph.expandGraph(newNodeData, newEdgeData);
    res.send('Graph expanded successfully');
  } catch (error) {
    res.status(500).send('Error expanding graph: ' + error.message);
  }
});

app.post('/adapt-to-dynamic-environment', (req, res) => {
  try {
    const updatedNodeData = req.body.updatedNodeData;
    const updatedEdgeData = req.body.updatedEdgeData;
    knowledgeGraph.adaptToDynamicEnvironment(updatedNodeData, updatedEdgeData);
    res.send('Graph adapted to dynamic environment successfully');
  } catch (error) {
    res.status(500).send('Error adapting to dynamic environment: ' + error.message);
  }
});

app.get('/query-graph', (req, res) => {
  try {
    const query = req.query.query;
    const results = knowledgeGraph.queryGraph(query);
    res.json(results);
  } catch (error) {
    res.status(500).send('Error querying graph: ' + error.message);
  }
});

app.get('/shortest-path', (req, res) => {
  try {
    const source = req.query.source;
    const target = req.query.target;
    const shortestPath = knowledgeGraph.getShortestPath(source, target);
    res.json(shortestPath);
  } catch (error) {
    res.status(500).send('Error getting shortest path: ' + error.message);
  }
});

app.get('/neighbors', (req, res) => {
  try {
    const nodeId = req.query.nodeId;
    const neighbors = knowledgeGraph.getNeighbors(nodeId);
    res.json(neighbors);
  } catch (error) {
    res.status(500).send('Error getting neighbors: ' + error.message);
  }
});

app.get('/graph-size', (req, res) => {
  try {
    const graphSize = knowledgeGraph.getGraphSize();
    res.json(graphSize);
  } catch (error) {
    res.status(500).send('Error getting graph size: ' + error.message);
  }
});

app.get('/graph-density', (req, res) => {
  try {
    const graphDensity = knowledgeGraph.getGraphDensity();
    res.json(graphDensity);
  } catch (error) {
    res.status(500).send('Error getting graph density: ' + error.message);
  }
});

app.get('/centrality', (req, res) => {
  try {
    const nodeId = req.query.nodeId;
    const centrality = knowledgeGraph.getCentrality(nodeId);
    res.json(centrality);
  } catch (error) {
    res.status(500).send('Error getting centrality: ' + error.message);
  }
});

app.get('/cluster-coefficient', (req, res) => {
  try {
    const nodeId = req.query.nodeId;
    const clusterCoefficient = knowledgeGraph.getClusterCoefficient(nodeId);
    res.json(clusterCoefficient);
  } catch (error) {
    res.status(500).send('Error getting cluster coefficient: ' + error.message);
  }
});

app.get('/community-structure', (req, res) => {
  try {
    const communityStructure = knowledgeGraph.getCommunityStructure();
    res.json(communityStructure);
  } catch (error) {
    res.status(500).send('Error getting community structure: ' + error.message);
  }
});

app.get('/graph-data', (req, res) => {
  try {
    const graphData = knowledgeGraph.getGraphData();
    res.json(graphData);
  } catch (error) {
    res.status(500).send('Error getting graph data: ' + error.message);
  }
});

app.get('/graph-statistics', (req, res) => {
  try {
    const graphStatistics = knowledgeGraph.getGraphStatistics();
    res.json(graphStatistics);
  } catch (error) {
    res.status(500).send('Error getting graph statistics: ' + error.message);
  }
});

app.get('/connected-components', (req, res) => {
  try {
    const connectedComponents = knowledgeGraph.getConnectedComponents();
    res.json(connectedComponents);
  } catch (error) {
    res.status(500).send('Error getting connected components: ' + error.message);
  }
});

app.get('/strongly-connected-components', (req, res) => {
  try {
    const stronglyConnectedComponents = knowledgeGraph.getStronglyConnectedComponents();
    res.json(stronglyConnectedComponents);
  } catch (error) {
    res.status(500).send('Error getting strongly connected components: ' + error.message);
  }
});

app.listen(3000, () => {
  console.log('Server listening on port 3000');
});