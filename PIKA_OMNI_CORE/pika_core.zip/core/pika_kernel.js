const express = require('express');
const app = express();
const port = 3000;
const natural = require('natural');
const wordnet = new natural.WordNet();
const stopwords = require('stopwords').english;
const lemmatizer = require('wink-lemmatizer');

app.use(express.json());

let knowledgeBase = {
  "greeting": "Hello, how can I assist you today?",
  "introduction": "I'm an AI designed to provide information and answer questions.",
  "default": "I didn't understand your question. Please try rephrasing.",
  "entity_recognition": "I've identified the following entities: ",
  "intent_detection": "I've detected the following intentions: "
};

let knowledgeGraph = {
  "entities": {
    "person": ["human", "individual", "being"],
    "organization": ["company", "firm", "institution"],
    "location": ["place", "city", "country"]
  },
  "intentions": {
    "greeting": ["hello", "hi", "hey"],
    "introduction": ["who are you", "what is your purpose", "what do you do"],
    "entity_recognition": ["what is", "who is", "where is"],
    "intent_detection": ["why", "how", "what"]
  }
};

let entityRecognitionModel = (query) => {
  let tokens = query.toLowerCase().split(" ");
  tokens = tokens.filter(token => !stopwords.includes(token));
  tokens = tokens.map(token => lemmatizer.lemmatize(token));
  let recognizedEntities = [];

  Object.keys(knowledgeGraph.entities).forEach(entity => {
    knowledgeGraph.entities[entity].forEach(keyword => {
      if (tokens.includes(keyword)) {
        recognizedEntities.push(entity);
      }
    });
  });

  return recognizedEntities;
};

let intentDetectionModel = (query) => {
  let tokens = query.toLowerCase().split(" ");
  tokens = tokens.filter(token => !stopwords.includes(token));
  tokens = tokens.map(token => lemmatizer.lemmatize(token));
  let matchedIntentions = Object.keys(knowledgeGraph.intentions).filter(intention => {
    return knowledgeGraph.intentions[intention].some(keyword => tokens.includes(keyword));
  });

  return matchedIntentions;
};

app.post('/query', (req, res) => {
  const query = req.body.query;
  let response = knowledgeBase.default;

  let recognizedEntities = entityRecognitionModel(query);
  let detectedIntentions = intentDetectionModel(query);

  if (detectedIntentions.includes("greeting")) {
    response = knowledgeBase.greeting;
  } else if (detectedIntentions.includes("introduction")) {
    response = knowledgeBase.introduction;
  } else if (detectedIntentions.includes("entity_recognition")) {
    response = knowledgeBase.entity_recognition + recognizedEntities.join(", ");
  } else if (detectedIntentions.includes("intent_detection")) {
    response = knowledgeBase.intent_detection + detectedIntentions.join(", ");
  }

  res.json({ response: response, entities: recognizedEntities, intentions: detectedIntentions });
});

app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});