const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

class KnowledgeGraph {
  constructor() {
    this.graph = {};
    this.learningRate = 0.1;
    this.maxNodes = 1000;
    this.maxEdges = 10000;
    this.weights = {};
  }

  addNode(nodeId, nodeData) {
    if (!this.graph[nodeId] && Object.keys(this.graph).length < this.maxNodes) {
      this.graph[nodeId] = nodeData;
      this.graph[nodeId].edges = [];
      this.weights[nodeId] = {};
    }
  }

  addEdge(fromNodeId, toNodeId) {
    if (this.graph[fromNodeId] && this.graph[toNodeId] && this.graph[fromNodeId].edges.length < this.maxEdges) {
      if (!this.graph[fromNodeId].edges.includes(toNodeId)) {
        this.graph[fromNodeId].edges.push(toNodeId);
      }
    }
  }

  optimizeGraph() {
    const visited = new Set();
    const optimizedGraph = {};

    function dfs(nodeId) {
      if (visited.has(nodeId)) return;
      visited.add(nodeId);

      if (this.graph[nodeId]) {
        optimizedGraph[nodeId] = this.graph[nodeId];
        if (this.graph[nodeId].edges) {
          this.graph[nodeId].edges.forEach((edgeNodeId) => {
            dfs.call(this, edgeNodeId);
          });
        }
      }
    }

    Object.keys(this.graph).forEach((nodeId) => {
      dfs.call(this, nodeId);
    });

    this.graph = optimizedGraph;
  }

  incrementalLearning(newData) {
    const newNodeId = uuidv4();
    this.addNode(newNodeId, { data: newData });

    Object.keys(this.graph).forEach((nodeId) => {
      if (this.graph[nodeId].edges) {
        this.graph[nodeId].edges.forEach((edgeNodeId) => {
          if (this.graph[edgeNodeId].data === newData) {
            this.addEdge(nodeId, newNodeId);
          }
        });
      }
    });

    this.updateWeights();
  }

  updateWeights() {
    Object.keys(this.graph).forEach((nodeId) => {
      if (this.graph[nodeId].edges) {
        this.graph[nodeId].edges.forEach((edgeNodeId) => {
          const weight = this.calculateWeight(nodeId, edgeNodeId);
          this.weights[nodeId][edgeNodeId] = weight;
        });
      }
    });
  }

  calculateWeight(nodeId, edgeNodeId) {
    const similarity = this.calculateSimilarity(nodeId, edgeNodeId);
    return similarity * this.learningRate;
  }

  calculateSimilarity(nodeId, edgeNodeId) {
    const nodeData = this.graph[nodeId].data;
    const edgeNodeData = this.graph[edgeNodeId].data;
    return this.jaccardSimilarity(nodeData, edgeNodeData);
  }

  jaccardSimilarity(setA, setB) {
    const intersection = new Set([...setA].filter(x => setB.has(x)));
    const union = new Set([...setA, ...setB]);
    return intersection.size / union.size;
  }

  saveGraph() {
    fs.writeFileSync('graph.json', JSON.stringify(this.graph, null, 2));
    fs.writeFileSync('weights.json', JSON.stringify(this.weights, null, 2));
  }

  loadGraph() {
    try {
      const graphData = fs.readFileSync('graph.json', 'utf8');
      this.graph = JSON.parse(graphData);
      const weightsData = fs.readFileSync('weights.json', 'utf8');
      this.weights = JSON.parse(weightsData);
    } catch (err) {
      console.error(err);
    }
  }

  getWeight(nodeId, edgeNodeId) {
    return this.weights[nodeId][edgeNodeId];
  }

  getNeighbors(nodeId) {
    return this.graph[nodeId].edges;
  }

  getNodes() {
    return Object.keys(this.graph);
  }

  getNodeData(nodeId) {
    return this.graph[nodeId].data;
  }
}

const knowledgeGraph = new KnowledgeGraph();

knowledgeGraph.addNode('node1', { data: new Set(['data1', 'data2']) });
knowledgeGraph.addNode('node2', { data: new Set(['data2', 'data3']) });
knowledgeGraph.addEdge('node1', 'node2');

knowledgeGraph.optimizeGraph();

knowledgeGraph.incrementalLearning(new Set(['data3', 'data4']));

knowledgeGraph.saveGraph();
knowledgeGraph.loadGraph();

console.log(knowledgeGraph.graph);
console.log(knowledgeGraph.weights);
console.log(knowledgeGraph.getWeight('node1', 'node2'));
console.log(knowledgeGraph.getNeighbors('node1'));
console.log(knowledgeGraph.getNodes());
console.log(knowledgeGraph.getNodeData('node1'));